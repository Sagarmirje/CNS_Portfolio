#!/usr/bin/env python3
"""
Offline Non-Repudiation Transcript Verifier.
Validates transcript integrity, SessionReceipt signature, and every message signature.
Usage: python tools/verify_transcript.py <transcript_path> <receipt_path> <peer_cert_path>
"""

import argparse
import hashlib
import json
import os
import sys

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import rsa

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.common.utils import b64_decode
from app.crypto.pki import get_certificate_fingerprint, load_certificate
from app.crypto.sign import compute_message_hash, verify_data, verify_hash


def verify_offline_transcript(
    transcript_path: str,
    receipt_path: str,
    peer_cert_path: str,
) -> bool:
    """
    Perform complete offline cryptographic audit of transcript:
    1. Recompute SHA-256 hash of entire transcript file.
    2. Compare against transcript_sha256 in SessionReceipt.
    3. Verify RSA signature of SessionReceipt using peer's public key.
    4. For each message line:
       a. Check peer certificate fingerprint match.
       b. Recompute h = SHA-256(seqno || ts || ct).
       c. Verify RSA signature with peer's public key.
    Prints PASS / FAIL per check.
    """
    print("=" * 65)
    print("      SecureChat Cryptographic Transcript Verifier      ")
    print("=" * 65)

    all_passed = True

    # Check files exist
    for p, desc in [(transcript_path, "Transcript"), (receipt_path, "Receipt"), (peer_cert_path, "Peer Cert")]:
        if not os.path.exists(p):
            print(f"[FAIL] {desc} file not found: {p}")
            return False

    # Load peer certificate
    try:
        with open(peer_cert_path, "rb") as f:
            peer_cert = load_certificate(f.read())
        peer_pubkey = peer_cert.public_key()
        if not isinstance(peer_pubkey, rsa.RSAPublicKey):
            print("[FAIL] Peer public key is not an RSA public key.")
            return False
        expected_fingerprint = get_certificate_fingerprint(peer_cert)
        print(f"[+] Loaded Peer Certificate. Fingerprint: {expected_fingerprint[:16]}...")
    except Exception as e:
        print(f"[FAIL] Error loading peer certificate: {e}")
        return False

    # Load receipt
    try:
        with open(receipt_path, "r", encoding="utf-8") as f:
            receipt_json = json.load(f)
        receipt_data = receipt_json.get("receipt", {})
        receipt_sig_b64 = receipt_json.get("sig", "")
        recorded_hash = receipt_data.get("transcript_sha256", "")
    except Exception as e:
        print(f"[FAIL] Error parsing receipt JSON: {e}")
        return False

    # 1 & 2: Recompute transcript hash
    try:
        with open(transcript_path, "rb") as f:
            content = f.read()
        computed_hash = hashlib.sha256(content).hexdigest()

        if computed_hash == recorded_hash:
            print(f"[PASS] Transcript Hash Match: {computed_hash}")
        else:
            print(f"[FAIL] Transcript Hash Mismatch!")
            print(f"       Computed: {computed_hash}")
            print(f"       Recorded: {recorded_hash}")
            all_passed = False
    except Exception as e:
        print(f"[FAIL] Error reading transcript: {e}")
        return False

    # 3: Verify Receipt Signature
    try:
        canonical_receipt_bytes = json.dumps(receipt_data, sort_keys=True).encode("utf-8")
        sig_bytes = b64_decode(receipt_sig_b64)
        verify_data(peer_pubkey, canonical_receipt_bytes, sig_bytes)
        print(f"[PASS] SessionReceipt RSA Signature: VALID (Non-Repudiation established)")
    except Exception as e:
        print(f"[FAIL] SessionReceipt RSA Signature: INVALID ({e})")
        all_passed = False

    # 4: Verify Individual Message Lines
    try:
        with open(transcript_path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]

        print(f"[*] Auditing {len(lines)} individual message signature(s)...")
        msg_failures = 0

        for idx, line in enumerate(lines, start=1):
            parts = [p.strip() for p in line.split("|")]
            if len(parts) != 5:
                print(f"  [FAIL] Line {idx}: Invalid field count ({len(parts)} != 5)")
                msg_failures += 1
                continue

            seqno_str, ts_str, ct_b64, sig_b64, fp = parts

            # Fingerprint check
            if fp.lower() != expected_fingerprint.lower():
                print(f"  [FAIL] Line {idx} (seq={seqno_str}): Fingerprint mismatch ({fp} != {expected_fingerprint})")
                msg_failures += 1
                continue

            # Signature check
            try:
                seqno = int(seqno_str)
                ts = int(ts_str)
                digest = compute_message_hash(seqno, ts, ct_b64)
                sig_raw = b64_decode(sig_b64)
                verify_hash(peer_pubkey, digest, sig_raw)
            except Exception as e:
                print(f"  [FAIL] Line {idx} (seq={seqno_str}): Signature verification failed ({e})")
                msg_failures += 1
                continue

        if msg_failures == 0:
            print(f"[PASS] All {len(lines)} Message Signatures: VERIFIED")
        else:
            print(f"[FAIL] {msg_failures} of {len(lines)} Message Signatures FAILED verification.")
            all_passed = False

    except Exception as e:
        print(f"[FAIL] Error reading messages from transcript: {e}")
        return False

    print("-" * 65)
    if all_passed:
        print("[SUCCESS] All non-repudiation cryptographic checks PASSED!")
    else:
        print("[FAILURE] One or more cryptographic verification checks FAILED!")
    print("=" * 65)

    return all_passed


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify transcript and SessionReceipt.")
    parser.add_argument("transcript", help="Path to transcript .log file")
    parser.add_argument("receipt", help="Path to SessionReceipt .json file")
    parser.add_argument("peer_cert", help="Path to peer's X.509 certificate .crt file")
    args = parser.parse_args()

    success = verify_offline_transcript(args.transcript, args.receipt, args.peer_cert)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
