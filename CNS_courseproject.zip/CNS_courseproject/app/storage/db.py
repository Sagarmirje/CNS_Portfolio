"""
User storage and authentication database layer.
Supports MySQL with parameterised queries and automatic SQLite fallback.
Uses 16-byte cryptographically secure random salts and constant-time hash comparison.
"""

import hashlib
import logging
import os
import sqlite3
from typing import Optional, Tuple
from dotenv import load_dotenv

import pymysql

from app.common.utils import constant_time_compare

logger = logging.getLogger("securechat.db")
load_dotenv()


class DatabaseManager:
    """Manages secure user registration and authentication credentials."""

    def __init__(
        self,
        db_type: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        database: Optional[str] = None,
        sqlite_path: Optional[str] = None,
    ):
        self.db_type = (db_type or os.getenv("DB_TYPE", "mysql")).lower()
        self.host = host or os.getenv("DB_HOST", "127.0.0.1")
        self.port = int(port or os.getenv("DB_PORT", "3306"))
        self.user = user or os.getenv("DB_USER", "root")
        self.password = password or os.getenv("DB_PASSWORD", "")
        self.database = database or os.getenv("DB_NAME", "securechat")
        self.sqlite_path = sqlite_path or os.getenv("SQLITE_DB_PATH", "securechat.db")
        self._init_storage()

    def _init_storage(self) -> None:
        """Initialize database connection and create users table if needed."""
        if self.db_type == "mysql":
            try:
                # First ensure the database exists
                conn = pymysql.connect(
                    host=self.host,
                    port=self.port,
                    user=self.user,
                    password=self.password,
                    autocommit=True,
                )
                with conn.cursor() as cur:
                    cur.execute(f"CREATE DATABASE IF NOT EXISTS `{self.database}`")
                conn.close()

                # Create users table
                conn = self._get_mysql_connection()
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        CREATE TABLE IF NOT EXISTS users (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            email VARCHAR(255) UNIQUE NOT NULL,
                            username VARCHAR(64) UNIQUE NOT NULL,
                            salt VARBINARY(16) NOT NULL,
                            pwd_hash CHAR(64) NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                        """
                    )
                conn.close()
                logger.info("Connected to MySQL database '%s'.", self.database)
                return
            except Exception as e:
                logger.warning(
                    "MySQL connection failed (%s). Falling back to SQLite (%s).",
                    e,
                    self.sqlite_path,
                )
                self.db_type = "sqlite"

        # SQLite initialization
        conn = sqlite3.connect(self.sqlite_path)
        with conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT UNIQUE NOT NULL,
                    username TEXT UNIQUE NOT NULL,
                    salt BLOB NOT NULL,
                    pwd_hash TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """
            )
        conn.close()
        logger.info("Initialized SQLite database '%s'.", self.sqlite_path)

    def _get_mysql_connection(self):
        return pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            database=self.database,
            autocommit=True,
            cursorclass=pymysql.cursors.DictCursor,
        )

    def register_user(self, email: str, username: str, password: str) -> Tuple[bool, str]:
        """
        Register a new user with a random 16-byte salt and SHA-256(salt || password).
        Uses parameterized queries to prevent SQL injection.
        """
        if not email or not username or not password:
            return False, "EMPTY_FIELDS"

        # Generate 16-byte cryptographically secure random salt
        salt = os.urandom(16)
        pwd_hash = hashlib.sha256(salt + password.encode("utf-8")).hexdigest()

        if self.db_type == "mysql":
            conn = None
            try:
                conn = self._get_mysql_connection()
                with conn.cursor() as cur:
                    sql = "INSERT INTO users (email, username, salt, pwd_hash) VALUES (%s, %s, %s, %s)"
                    cur.execute(sql, (email, username, salt, pwd_hash))
                return True, "OK"
            except pymysql.err.IntegrityError:
                return False, "DUPLICATE_USER"
            except Exception as e:
                logger.error("DB error during registration: %s", e)
                return False, f"DB_ERROR: {e}"
            finally:
                if conn:
                    conn.close()
        else:
            conn = sqlite3.connect(self.sqlite_path)
            try:
                with conn:
                    sql = "INSERT INTO users (email, username, salt, pwd_hash) VALUES (?, ?, ?, ?)"
                    conn.execute(sql, (email, username, salt, pwd_hash))
                return True, "OK"
            except sqlite3.IntegrityError:
                return False, "DUPLICATE_USER"
            except Exception as e:
                logger.error("SQLite error during registration: %s", e)
                return False, f"DB_ERROR: {e}"
            finally:
                conn.close()

    def verify_user(self, username: str, password: str) -> Tuple[bool, str]:
        """
        Verify login credentials using constant-time hash comparison.
        Returns (True, "OK") or (False, "BAD_CREDENTIALS").
        """
        if not username or not password:
            return False, "BAD_CREDENTIALS"

        salt: Optional[bytes] = None
        stored_hash: Optional[str] = None

        if self.db_type == "mysql":
            conn = None
            try:
                conn = self._get_mysql_connection()
                with conn.cursor() as cur:
                    sql = "SELECT salt, pwd_hash FROM users WHERE username = %s"
                    cur.execute(sql, (username,))
                    row = cur.fetchone()
                    if row:
                        salt = row["salt"]
                        stored_hash = row["pwd_hash"]
            except Exception as e:
                logger.error("DB error during verification: %s", e)
                return False, "DB_ERROR"
            finally:
                if conn:
                    conn.close()
        else:
            conn = sqlite3.connect(self.sqlite_path)
            try:
                cur = conn.cursor()
                sql = "SELECT salt, pwd_hash FROM users WHERE username = ?"
                cur.execute(sql, (username,))
                row = cur.fetchone()
                if row:
                    salt = row[0]
                    stored_hash = row[1]
            except Exception as e:
                logger.error("SQLite error during verification: %s", e)
                return False, "DB_ERROR"
            finally:
                conn.close()

        if not salt or not stored_hash:
            return False, "BAD_CREDENTIALS"

        # Compute candidate hash: SHA-256(salt || password)
        candidate_hash = hashlib.sha256(salt + password.encode("utf-8")).hexdigest()

        # Constant-time comparison prevents timing attacks
        if constant_time_compare(stored_hash, candidate_hash):
            return True, "OK"
        return False, "BAD_CREDENTIALS"
