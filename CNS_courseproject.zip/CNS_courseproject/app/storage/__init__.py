"""Storage modules for credentials database and session transcripts."""
