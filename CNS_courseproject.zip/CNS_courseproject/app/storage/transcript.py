"""
Transcript management and non-repudiation SessionReceipt generation.
Maintains append-only cryptographic logs of all exchanged messages.
"""

import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Tuple

from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import rsa

from app.common.utils import b64_decode, b64_encode, now_ms
from app.crypto.pki import get_certificate_fingerprint, load_certificate
from app.crypto.sign import compute_message_hash, sign_data, verify_data, verify_hash


class TranscriptLogger:
    """Manages append-only transcript logging for a SecureChat session."""

    def __init__(
        self,
        session_id: str,
        role: str,
        peer_cert: x509.Certificate,
        transcripts_dir: str = "transcripts",
    ):
        self.session_id = session_id
        self.role = role.lower()
        self.peer_cert = peer_cert
        self.peer_fingerprint = get_certificate_fingerprint(peer_cert)
        self.transcripts_dir = transcripts_dir
        os.makedirs(self.transcripts_dir, exist_ok=True)
        self.file_path = os.path.join(self.transcripts_dir, f"{session_id}_{self.role}.log")
        self.first_seq: Optional[int] = None
        self.last_seq: Optional[int] = None

    def log_message(self, seqno: int, ts: int, ct_b64: str, sig_b64: str) -> None:
        """
        Append a message record to the transcript file:
        seqno | ts | ct_b64 | sig_b64 | peer_cert_fingerprint_sha256
        """
        if self.first_seq is None:
            self.first_seq = seqno
        self.last_seq = seqno

        line = f"{seqno} | {ts} | {ct_b64} | {sig_b64} | {self.peer_fingerprint}\n"
        with open(self.file_path, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()

    def compute_transcript_hash(self) -> str:
        """
        Compute TranscriptHash = SHA-256(concatenation of all lines in transcript file).
        """
        if not os.path.exists(self.file_path):
            return hashlib.sha256(b"").hexdigest()

        with open(self.file_path, "rb") as f:
            content = f.read()
        return hashlib.sha256(content).hexdigest()

    def generate_receipt(
        self,
        signer_key: rsa.RSAPrivateKey,
        peer_name: str,
        override_hash: Optional[str] = None,
        override_first_seq: Optional[int] = None,
        override_last_seq: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Generate and sign a SessionReceipt:
        { "peer": ..., "first_seq": ..., "last_seq": ..., "transcript_sha256": ..., "ts": ... }
        Returns a dictionary containing receipt data and base64 signature.
        """
        transcript_hash = override_hash if override_hash is not None else self.compute_transcript_hash()
        first_seq = override_first_seq if override_first_seq is not None else (self.first_seq if self.first_seq is not None else 0)
        last_seq = override_last_seq if override_last_seq is not None else (self.last_seq if self.last_seq is not None else 0)

        receipt_data = {
            "peer": peer_name,
            "first_seq": first_seq,
            "last_seq": last_seq,
            "transcript_sha256": transcript_hash,
            "ts": now_ms(),
        }

        canonical_bytes = json.dumps(receipt_data, sort_keys=True).encode("utf-8")
        raw_sig = sign_data(signer_key, canonical_bytes)
        sig_b64 = b64_encode(raw_sig)

        return {
            "receipt": receipt_data,
            "sig": sig_b64,
        }

    def save_receipt(self, receipt_dict: Dict[str, Any], filename: Optional[str] = None) -> str:
        """Save SessionReceipt to transcripts directory."""
        fname = filename or f"{self.session_id}_{self.role}_receipt.json"
        receipt_path = os.path.join(self.transcripts_dir, fname)
        with open(receipt_path, "w", encoding="utf-8") as f:
            json.dump(receipt_dict, f, indent=2)
        return receipt_path


def verify_session_receipt(
    receipt_data: Dict[str, Any],
    sig_b64: str,
    signer_public_key: rsa.RSAPublicKey,
) -> bool:
    """Verify cryptographic signature on a SessionReceipt."""
    canonical_bytes = json.dumps(receipt_data, sort_keys=True).encode("utf-8")
    sig_bytes = b64_decode(sig_b64)
    return verify_data(signer_public_key, canonical_bytes, sig_bytes)
