"""Cryptographic and general utility functions."""

import base64
import hmac
import os
import stat
import time
from typing import Union


def b64_encode(data: bytes) -> str:
    """Encode bytes to a base64 UTF-8 string."""
    return base64.b64encode(data).decode("utf-8")


def b64_decode(data: str) -> bytes:
    """Decode a base64 UTF-8 string to bytes."""
    return base64.b64decode(data.encode("utf-8"))


def now_ms() -> int:
    """Return the current Unix timestamp in milliseconds."""
    return int(time.time() * 1000)


def constant_time_compare(val1: Union[bytes, str], val2: Union[bytes, str]) -> bool:
    """Perform constant-time comparison to prevent timing attacks."""
    if isinstance(val1, str):
        val1 = val1.encode("utf-8")
    if isinstance(val2, str):
        val2 = val2.encode("utf-8")
    return hmac.compare_digest(val1, val2)


def set_private_key_permissions(path: str) -> None:
    """
    Set file permissions to 0600 (read/write for owner only).
    Handles POSIX permissions and gracefully handles Windows environments.
    """
    try:
        if os.name == "posix":
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
        elif os.name == "nt":
            # On Windows, os.chmod only affects read-only attribute;
            # still execute it to ensure basic protection.
            os.chmod(path, stat.S_IREAD | stat.S_IWRITE)
    except Exception:
        # Avoid crashing if filesystem/OS does not support standard chmod
        pass
