"""
Protocol definitions and TCP message framing for SecureChat.
Implements 4-byte big-endian length-prefixed JSON framing with maximum frame size protection.
"""

import json
import socket
import struct
from typing import Any, Dict

# Maximum frame size to prevent Denial of Service (DoS) memory exhaustion: 64 KB
MAX_FRAME_SIZE = 65536
LENGTH_PREFIX_SIZE = 4  # 4-byte unsigned integer (!I)


class ProtocolError(Exception):
    """Base exception for network framing and protocol errors."""
    pass


class FrameTooLargeError(ProtocolError):
    """Raised when an incoming frame exceeds the maximum allowed size."""
    pass


class ConnectionClosedError(ProtocolError):
    """Raised when a socket connection closes unexpectedly during read."""
    pass


def _recv_all(sock: socket.socket, length: int) -> bytes:
    """Read exactly length bytes from socket, or raise ConnectionClosedError."""
    buf = bytearray()
    while len(buf) < length:
        chunk = sock.recv(length - len(buf))
        if not chunk:
            raise ConnectionClosedError("Socket closed while reading frame.")
        buf.extend(chunk)
    return bytes(buf)


def send_frame(sock: socket.socket, data: bytes) -> None:
    """Send length-prefixed raw bytes over TCP socket."""
    if len(data) > MAX_FRAME_SIZE:
        raise FrameTooLargeError(
            f"Outgoing frame size ({len(data)} bytes) exceeds maximum ({MAX_FRAME_SIZE} bytes)."
        )
    length_prefix = struct.pack("!I", len(data))
    sock.sendall(length_prefix + data)


def recv_frame(sock: socket.socket) -> bytes:
    """Receive length-prefixed raw bytes from TCP socket."""
    prefix = _recv_all(sock, LENGTH_PREFIX_SIZE)
    (frame_len,) = struct.unpack("!I", prefix)
    if frame_len > MAX_FRAME_SIZE:
        raise FrameTooLargeError(
            f"Incoming frame size ({frame_len} bytes) exceeds maximum allowed ({MAX_FRAME_SIZE} bytes)."
        )
    if frame_len == 0:
        return b""
    return _recv_all(sock, frame_len)


def send_message(sock: socket.socket, message: Dict[str, Any]) -> None:
    """Serialize dictionary to JSON and send with length prefix."""
    json_bytes = json.dumps(message).encode("utf-8")
    send_frame(sock, json_bytes)


def recv_message(sock: socket.socket) -> Dict[str, Any]:
    """Receive length-prefixed frame and deserialize from JSON."""
    raw_data = recv_frame(sock)
    try:
        return json.loads(raw_data.decode("utf-8"))
    except json.JSONDecodeError as e:
        raise ProtocolError(f"Failed to decode JSON message: {e}")
