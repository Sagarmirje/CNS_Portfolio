"""
SecureChat Web Interface.
Provides an interactive, modern web-based graphical interface for SecureChat
with real-time cryptographic inspection, packet breakdowns, and transcript audits.
"""

import json
import logging
import os
import re
import sys
import threading
import time
import traceback
from typing import Dict, List, Optional

from flask import Flask, jsonify, render_template, request

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.client import SecureChatClient
from app.common.protocol import send_message
from app.crypto.pki import get_certificate_fingerprint

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("securechat.webui")

# Active web sessions: { username: {"client": SecureChatClient, "messages": [], ...} }
web_sessions: Dict[str, dict] = {}
sessions_lock = threading.Lock()
CLIENT_CERT_DIR = "certs"
USERNAME_PATTERN = re.compile(r"[A-Za-z0-9_-]{1,32}\Z")


def _clear_session(username: str) -> None:
    """Remove a user session and try to close the socket."""
    with sessions_lock:
        state = web_sessions.pop(username, None)
    if state and state.get("client"):
        try:
            state["client"].is_connected = False
            if state["client"].sock:
                state["client"].sock.close()
        except Exception:
            pass


def _fresh_client(username: str, host: str = "127.0.0.1", port: int = 8443) -> SecureChatClient:
    """Create a brand-new SecureChatClient and store it in web_sessions."""
    _clear_session(username)
    client = SecureChatClient(username=username, host=host, port=port)
    with sessions_lock:
        web_sessions[username] = {
            "client": client,
            "messages": [],
            "connected": False,
            "session_active": False,
        }
    return client


def _get_state(username: str) -> Optional[dict]:
    with sessions_lock:
        return web_sessions.get(username)


def _valid_username(username: object) -> bool:
    return isinstance(username, str) and USERNAME_PATTERN.fullmatch(username) is not None


@app.route("/api/identities", methods=["GET"])
def api_identities():
    """List client identities with both a certificate and private key present."""
    if not os.path.isdir(CLIENT_CERT_DIR):
        return jsonify({"identities": []})

    identities = []
    for filename in os.listdir(CLIENT_CERT_DIR):
        username, extension = os.path.splitext(filename)
        if extension.lower() != ".crt" or username.lower() in {"ca", "server"}:
            continue
        cert_path = os.path.join(CLIENT_CERT_DIR, filename)
        key_path = os.path.join(CLIENT_CERT_DIR, f"{username}.key")
        if os.path.isfile(cert_path) and os.path.isfile(key_path):
            identities.append(username)
    return jsonify({"identities": sorted(identities, key=str.lower)})


def _is_socket_alive(client: SecureChatClient) -> bool:
    """Quick check: is the underlying TCP socket still connected?"""
    if client.sock is None:
        return False
    try:
        # Try a non-blocking peek; if it fails the socket is dead
        client.sock.setblocking(False)
        try:
            data = client.sock.recv(1, 0x02)  # MSG_PEEK on Windows
            # If recv returns b'' the peer closed
            if data == b'':
                return False
        except BlockingIOError:
            # No data available — socket is still alive
            pass
        except (ConnectionError, OSError):
            return False
        finally:
            client.sock.setblocking(True)
        return True
    except Exception:
        return False


def background_listener(username: str):
    """Background message receiver thread for web client."""
    state = _get_state(username)
    if not state:
        return
    client = state["client"]

    while state.get("connected") and client.sock:
        try:
            from app.common.protocol import recv_message
            msg = recv_message(client.sock)
            msg_type = msg.get("type")

            if msg_type == "msg":
                success, code, result = client.session.process_incoming_message(msg)
                record = {
                    "id": len(state["messages"]) + 1,
                    "direction": "incoming",
                    "text": result if success else f"[REJECTED] {code}: {result}",
                    "status": "VERIFIED" if success else f"REJECTED ({code})",
                    "raw": msg,
                    "ts": msg.get("ts"),
                    "seqno": msg.get("seqno"),
                }
                state["messages"].append(record)
            elif msg_type == "error":
                state["messages"].append({
                    "id": len(state["messages"]) + 1,
                    "direction": "system",
                    "text": f"Server Error [{msg.get('code')}]: {msg.get('message')}",
                    "status": "ERROR",
                    "raw": msg,
                })
            elif msg_type == "receipt_exchange":
                receipt_for_peer = msg.get("receipt_for_peer")
                if receipt_for_peer:
                    client.session.transcript.save_receipt(
                        receipt_for_peer,
                        filename=f"{client.session_id}_client_peer_receipt.json",
                    )
                server_summary = msg.get("server_summary", {})
                if server_summary and "transcript_sha256" in server_summary:
                    client_signed_pkg = client.session.transcript.generate_receipt(
                        signer_key=client.client_key,
                        peer_name="server",
                        override_hash=server_summary.get("transcript_sha256"),
                        override_first_seq=server_summary.get("first_seq"),
                        override_last_seq=server_summary.get("last_seq"),
                    )
                    send_message(client.sock, {"type": "receipt_ack", "receipt_pkg": client_signed_pkg})
        except Exception as e:
            log.info("Listener for %s ended: %s", username, e)
            break


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/connect", methods=["POST"])
def api_connect():
    data = request.json or {}
    username = data.get("username", "alice")
    if not _valid_username(username):
        return jsonify({"ok": False, "error": "Username must be 1-32 letters, numbers, underscores, or hyphens."}), 400
    try:
        client = _fresh_client(username)
        ok = client.connect()
        if not ok:
            _clear_session(username)
            return jsonify({"ok": False, "error": "Handshake failed"}), 400

        state = _get_state(username)
        state["connected"] = True

        return jsonify({
            "ok": True,
            "username": username,
            "server_cn": "server",
            "server_fp": get_certificate_fingerprint(client.server_cert),
            "client_fp": get_certificate_fingerprint(client.client_cert),
            "temp_aes_derived": True,
        })
    except Exception as e:
        _clear_session(username)
        log.error("api_connect error: %s", traceback.format_exc())
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/auth", methods=["POST"])
def api_auth():
    data = request.json or {}
    username = data.get("username", "alice")
    if not _valid_username(username):
        return jsonify({"ok": False, "error": "Username must be 1-32 letters, numbers, underscores, or hyphens."}), 400
    action = data.get("action", "login")
    password = data.get("password", "")
    email = data.get("email", f"{username}@securechat.io")

    state = _get_state(username)
    client = state["client"] if state else None

    # If no session or the socket died, create a fresh connection
    if not client or not state.get("connected") or not _is_socket_alive(client):
        try:
            client = _fresh_client(username)
            ok = client.connect()
            if not ok:
                _clear_session(username)
                return jsonify({"ok": False, "error": "PKI Handshake or Temp DH failed"}), 400
            state = _get_state(username)
            state["connected"] = True
        except Exception as e:
            _clear_session(username)
            log.error("api_auth reconnect error: %s", traceback.format_exc())
            return jsonify({"ok": False, "error": f"Connection error: {e}"}), 500

    if action == "register":
        try:
            ok = client.register(email, password)
            # After register, the socket consumed one request/response cycle.
            # The temp key is still valid for a login on the same socket.
            return jsonify({
                "ok": ok,
                "action": "register",
                "msg": "Registered successfully! Now click Login." if ok else "Registration failed (User may already exist).",
            })
        except Exception as e:
            _clear_session(username)
            log.error("api_auth register error: %s", traceback.format_exc())
            return jsonify({"ok": False, "error": f"Registration error: {e}"}), 500
    else:
        try:
            ok = client.login(password)
            if ok:
                # Automatically perform authenticated session DH
                dh_ok = client.establish_session_key()
                if dh_ok:
                    state["session_active"] = True
                    threading.Thread(target=background_listener, args=(username,), daemon=True).start()
                    return jsonify({
                        "ok": True,
                        "action": "login",
                        "session_id": client.session_id,
                        "msg": "Login and Session Key Agreement successful! Ready to chat.",
                    })
                else:
                    _clear_session(username)
                    return jsonify({"ok": False, "error": "Session key agreement failed"}), 500
            else:
                _clear_session(username)
                return jsonify({"ok": False, "action": "login", "msg": "Invalid password or credentials."}), 401
        except Exception as e:
            _clear_session(username)
            log.error("api_auth login error: %s", traceback.format_exc())
            return jsonify({"ok": False, "error": f"Login error: {e}"}), 500


@app.route("/api/session_dh", methods=["POST"])
def api_session_dh():
    data = request.json or {}
    username = data.get("username", "alice")
    state = _get_state(username)
    if not state:
        return jsonify({"ok": False, "error": "No connection. Click Login first."}), 400
    client = state["client"]

    # If session is already established and active, return immediately
    if state.get("session_active") and client.session:
        return jsonify({
            "ok": True,
            "session_id": client.session_id,
            "cipher": "AES-128-CBC + PKCS#7",
            "signature": "RSA-SHA256 (PKCS#1 v1.5)",
        })

    try:
        ok = client.establish_session_key()
        if ok:
            state["session_active"] = True
            threading.Thread(target=background_listener, args=(username,), daemon=True).start()
            return jsonify({
                "ok": True,
                "session_id": client.session_id,
                "cipher": "AES-128-CBC + PKCS#7",
                "signature": "RSA-SHA256 (PKCS#1 v1.5)",
            })
        return jsonify({"ok": False, "error": "DH agreement failed"}), 400
    except Exception as e:
        log.error("api_session_dh error: %s", traceback.format_exc())
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/send", methods=["POST"])
def api_send():
    data = request.json or {}
    username = data.get("username", "alice")
    text = data.get("text", "")
    state = _get_state(username)
    if not state or not state.get("session_active"):
        return jsonify({"ok": False, "error": "No active session. Login first."}), 400
    client = state["client"]

    if not client.session:
        return jsonify({"ok": False, "error": "No active session"}), 400

    try:
        frame = client.session.create_message(text)
        send_message(client.sock, frame)
        return jsonify({"ok": True, "frame": frame})
    except Exception as e:
        log.error("api_send error: %s", traceback.format_exc())
        _clear_session(username)
        return jsonify({"ok": False, "error": f"Send failed: {e}"}), 500


@app.route("/api/messages", methods=["GET"])
def api_messages():
    username = request.args.get("username", "alice")
    state = _get_state(username)
    if not state:
        return jsonify({"messages": []})
    msgs = list(state["messages"])
    state["messages"].clear()
    return jsonify({"messages": msgs})


@app.route("/api/quit", methods=["POST"])
def api_quit():
    data = request.json or {}
    username = data.get("username", "alice")
    state = _get_state(username)
    if not state or not state.get("session_active"):
        return jsonify({"ok": False, "error": "No active session"}), 400
    client = state["client"]

    if not client.session:
        return jsonify({"ok": False, "error": "No active session"}), 400

    try:
        local_receipt = client.session.transcript.generate_receipt(
            signer_key=client.client_key,
            peer_name="server",
        )
        receipt_path = client.session.transcript.save_receipt(local_receipt)

        send_message(
            client.sock,
            {
                "type": "quit",
                "peer_summary": {
                    "first_seq": client.session.transcript.first_seq or 0,
                    "last_seq": client.session.transcript.last_seq or 0,
                    "transcript_sha256": client.session.transcript.compute_transcript_hash(),
                },
            },
        )
        time.sleep(0.5)
        return jsonify({"ok": True, "receipt": local_receipt, "saved_path": receipt_path})
    except Exception as e:
        log.error("api_quit error: %s", traceback.format_exc())
        return jsonify({"ok": False, "error": str(e)}), 500
    finally:
        _clear_session(username)


@app.route("/api/transcripts", methods=["GET"])
def api_transcripts():
    transcripts_dir = "transcripts"
    files = {}
    if os.path.exists(transcripts_dir):
        for fname in sorted(os.listdir(transcripts_dir)):
            if fname.endswith(".log") or fname.endswith(".json"):
                fpath = os.path.join(transcripts_dir, fname)
                try:
                    size = os.path.getsize(fpath)
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = f.read()
                    files[fname] = (content[:500] + "...") if size > 500 else content
                except Exception:
                    pass
    return jsonify(files)


@app.route("/api/run_audit", methods=["GET"])
def api_run_audit():
    import subprocess
    cmd = [sys.executable, "scripts/demo_attacks.py"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return jsonify({"output": res.stdout + ("\n--- STDERR ---\n" + res.stderr if res.stderr else "")})
    except Exception as e:
        return jsonify({"output": f"Audit execution error: {e}"})


@app.route("/api/simulate_attack", methods=["POST"])
def api_simulate_attack():
    data = request.json or {}
    attack_type = data.get("type", "tamper")
    username = data.get("username", "alice")
    state = _get_state(username)
    if not state or not state.get("session_active"):
        return jsonify({"status": "ERROR", "detail": "Login and establish session first."})
    client = state["client"]

    if not client.session:
        return jsonify({"status": "ERROR", "detail": "Establish session first."})

    try:
        msg = client.session.create_message("Secret attack payload")
        if attack_type == "tamper":
            from app.common.utils import b64_decode, b64_encode
            raw_ct = bytearray(b64_decode(msg["ct"]))
            raw_ct[-1] ^= 0x01
            msg["ct"] = b64_encode(bytes(raw_ct))
            send_message(client.sock, msg)
            return jsonify({"status": "ATTACK LAUNCHED", "detail": "Flipped 1 byte in ciphertext. Server will reject with SIG_FAIL."})
        elif attack_type == "replay":
            send_message(client.sock, msg)
            time.sleep(0.2)
            send_message(client.sock, msg)
            return jsonify({"status": "ATTACK LAUNCHED", "detail": "Sent identical message twice. Server will reject with REPLAY."})
        elif attack_type == "stale":
            from app.common.utils import b64_encode
            from app.crypto.sign import compute_message_hash, sign_hash
            msg["ts"] = msg["ts"] - 300000
            digest = compute_message_hash(msg["seqno"], msg["ts"], msg["ct"])
            msg["sig"] = b64_encode(sign_hash(client.client_key, digest))
            send_message(client.sock, msg)
            return jsonify({"status": "ATTACK LAUNCHED", "detail": "Sent message with ts - 5 mins. Server will reject with STALE."})
        return jsonify({"status": "UNKNOWN"})
    except Exception as e:
        log.error("simulate_attack error: %s", traceback.format_exc())
        return jsonify({"status": "ERROR", "detail": str(e)})


@app.route("/api/certs_info", methods=["GET"])
def api_certs_info():
    """Return parsed details of all system certificates for visual inspection."""
    from app.crypto.pki import get_certificate_cn, get_certificate_fingerprint, load_certificate
    certs = {}
    cert_files = {
        "Root CA": os.path.join(CLIENT_CERT_DIR, "ca.crt"),
        "Server": os.path.join(CLIENT_CERT_DIR, "server.crt"),
    }
    if os.path.isdir(CLIENT_CERT_DIR):
        for filename in os.listdir(CLIENT_CERT_DIR):
            username, extension = os.path.splitext(filename)
            if extension.lower() == ".crt" and username.lower() not in {"ca", "server"}:
                cert_files[f"{username} (Client)"] = os.path.join(CLIENT_CERT_DIR, filename)
    for label, path in cert_files.items():
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    c = load_certificate(f.read())
                certs[label] = {
                    "cn": get_certificate_cn(c),
                    "fingerprint": get_certificate_fingerprint(c),
                    "subject": c.subject.rfc4514_string(),
                    "issuer": c.issuer.rfc4514_string(),
                    "serial": str(c.serial_number),
                    "valid_from": str(c.not_valid_before_utc if hasattr(c, "not_valid_before_utc") else c.not_valid_before),
                    "valid_to": str(c.not_valid_after_utc if hasattr(c, "not_valid_after_utc") else c.not_valid_after),
                    "key_size": 2048,
                }
            except Exception as e:
                certs[label] = {"error": str(e)}
    return jsonify(certs)


@app.route("/api/db_stats", methods=["GET"])
def api_db_stats():
    """Return database statistics and users table status."""
    import sqlite3
    try:
        conn = sqlite3.connect("securechat.db")
        cur = conn.cursor()
        cur.execute("SELECT id, email, username, hex(salt), pwd_hash, created_at FROM users")
        rows = []
        for r in cur.fetchall():
            rows.append({
                "id": r[0],
                "email": r[1],
                "username": r[2],
                "salt": r[3][:16] + "...",
                "pwd_hash": r[4][:20] + "...",
                "created_at": r[5],
            })
        conn.close()
        return jsonify({"backend": "SQLite (securechat.db)", "users": rows})
    except Exception as e:
        return jsonify({"backend": "Unknown", "users": [], "error": str(e)})


def main():
    print("[*] Starting SecureChat Web Interface on http://127.0.0.1:5000 ...")
    app.run(host="127.0.0.1", port=5000, debug=False)


if __name__ == "__main__":
    main()
