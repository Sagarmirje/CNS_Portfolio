"""
SecureChat Interactive CLI Client.
Features mutual TLS-like certificate exchange, encrypted registration/login,
forward-secure authenticated Diffie-Hellman key agreement,
AES-128-CBC encryption with PKCS#7 padding, RSA-SHA256 signatures,
concurrent message sending/receiving, and SessionReceipt non-repudiation generation.
"""

import argparse
import getpass
import json
import logging
import os
import socket
import sys
import threading
import time
import uuid
from typing import Optional

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.common.protocol import (
    ConnectionClosedError,
    recv_message,
    send_message,
)
from app.common.utils import b64_decode, b64_encode
from app.crypto.aes import decrypt_aes_cbc, encrypt_aes_cbc
from app.crypto.dh import (
    DiffieHellman,
    sign_dh_exchange,
    verify_dh_exchange,
)
from app.crypto.pki import (
    PKIValidationError,
    certificate_to_pem,
    load_certificate,
    load_private_key,
    validate_certificate,
)
from app.crypto.session import SecureChatSession

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] %(message)s",
)
logger = logging.getLogger("securechat.client")


class SecureChatClient:
    """Manages secure connection, cryptographic handshake, and chat session."""

    def __init__(
        self,
        username: str,
        host: str = "127.0.0.1",
        port: int = 8443,
        ca_cert_path: str = "certs/ca.crt",
        cert_dir: str = "certs",
    ):
        self.username = username
        self.host = host
        self.port = port
        self.ca_cert_path = ca_cert_path
        self.client_cert_path = os.path.join(cert_dir, f"{username}.crt")
        self.client_key_path = os.path.join(cert_dir, f"{username}.key")

        self.sock: Optional[socket.socket] = None
        self.server_cert = None
        self.session: Optional[SecureChatSession] = None
        self.session_id = str(uuid.uuid4())[:8]
        self.is_connected = False
        self.temp_key: Optional[bytes] = None

        self._load_crypto_assets()

    def _load_crypto_assets(self) -> None:
        """Load Root CA certificate, client certificate, and private key."""
        if not os.path.exists(self.ca_cert_path):
            raise FileNotFoundError(f"Root CA cert missing at {self.ca_cert_path}. Run scripts/gen_ca.py first.")
        if not os.path.exists(self.client_cert_path) or not os.path.exists(self.client_key_path):
            raise FileNotFoundError(
                f"Client credentials missing for '{self.username}' at {self.client_cert_path}. "
                f"Run: python scripts/gen_cert.py {self.username} client"
            )

        with open(self.ca_cert_path, "rb") as f:
            self.ca_cert = load_certificate(f.read())
        with open(self.client_cert_path, "rb") as f:
            self.client_cert = load_certificate(f.read())
        with open(self.client_key_path, "rb") as f:
            self.client_key = load_private_key(f.read())

    def connect(self) -> bool:
        """Connect to server and perform mutual certificate validation."""
        print(f"\n[*] Connecting to SecureChat server at {self.host}:{self.port}...")
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))

        # Step 1 & 2: Mutual Certificate Exchange
        print("[*] Performing Mutual PKI Certificate Authentication...")
        send_message(self.sock, {"type": "handshake", "cert": certificate_to_pem(self.client_cert)})

        resp = recv_message(self.sock)
        if resp.get("type") != "handshake" or "cert" not in resp:
            print(f"[!] Server handshake failed: {resp}")
            return False

        server_cert_pem = resp["cert"]
        try:
            # Validate server certificate against Root CA
            validate_certificate(server_cert_pem, self.ca_cert, expected_cn="server")
            self.server_cert = load_certificate(server_cert_pem)
            print("[+] Server certificate successfully authenticated by Root CA! (CN: server)")
        except PKIValidationError as e:
            print(f"[!] Server certificate validation FAILED: {e}")
            self.sock.close()
            return False

        # Step 3: Temporary DH Exchange for protecting registration/login credentials
        print("[*] Performing Ephemeral Diffie-Hellman exchange to protect credentials...")
        temp_dh = DiffieHellman()
        send_message(self.sock, {"type": "dh_init", "dh_pub": temp_dh.public_key})

        server_dh_resp = recv_message(self.sock)
        if server_dh_resp.get("type") != "dh_init":
            print(f"[!] Temporary DH agreement failed: {server_dh_resp}")
            return False

        server_dh_pub = int(server_dh_resp["dh_pub"])
        self.temp_key = temp_dh.derive_key(server_dh_pub)
        print("[+] Temporary 128-bit AES channel established. Passwords will never travel in plaintext.")
        return True

    def register(self, email: str, password: str) -> bool:
        """Register account encrypted under temporary AES key."""
        payload = {
            "action": "register",
            "email": email,
            "username": self.username,
            "password": password,
        }
        ct = b64_encode(encrypt_aes_cbc(self.temp_key, json.dumps(payload).encode("utf-8")))
        send_message(self.sock, {"type": "auth_req", "ct": ct})

        resp_msg = recv_message(self.sock)
        resp_bytes = decrypt_aes_cbc(self.temp_key, b64_decode(resp_msg["ct"]))
        resp = json.loads(resp_bytes.decode("utf-8"))

        if resp.get("status") == "OK":
            print("[+] Registration successful! You can now log in.")
            return True
        else:
            print(f"[!] Registration failed: {resp.get('status')} - {resp.get('msg')}")
            return False

    def login(self, password: str) -> bool:
        """Login encrypted under temporary AES key."""
        payload = {
            "action": "login",
            "username": self.username,
            "password": password,
        }
        ct = b64_encode(encrypt_aes_cbc(self.temp_key, json.dumps(payload).encode("utf-8")))
        send_message(self.sock, {"type": "auth_req", "ct": ct})

        resp_msg = recv_message(self.sock)
        resp_bytes = decrypt_aes_cbc(self.temp_key, b64_decode(resp_msg["ct"]))
        resp = json.loads(resp_bytes.decode("utf-8"))

        if resp.get("status") == "OK":
            print(f"[+] Login successful as '{self.username}'!")
            return True
        else:
            print(f"[!] Login failed: {resp.get('status')} - {resp.get('msg')}")
            return False

    def establish_session_key(self) -> bool:
        """
        Step 4 & 5: Run fresh ephemeral authenticated Diffie-Hellman exchange.
        Signs DH public value and nonce with client's RSA private key.
        Derives session key K_session = Trunc16(SHA-256(big_endian(shared_secret))).
        """
        print("[*] Initiating Fresh Ephemeral Authenticated DH Session Key Agreement...")

        # 1. Receive server's authenticated DH parameters
        server_msg = recv_message(self.sock)
        if server_msg.get("type") != "session_dh":
            print(f"[!] Unexpected response during session key agreement: {server_msg}")
            return False

        server_dh_pub = int(server_msg["dh_pub"])
        server_nonce = b64_decode(server_msg["nonce"])
        server_sig = b64_decode(server_msg["sig"])

        # 2. Verify server's RSA signature using server certificate public key
        try:
            verify_dh_exchange(
                self.server_cert.public_key(),
                server_dh_pub,
                server_nonce,
                server_sig,
            )
            print("[+] Server DH signature verified using Server Certificate public key (MITM prevented)!")
        except Exception as e:
            print(f"[!] Server DH signature verification failed: {e}")
            return False

        # 3. Generate client's fresh DH and sign it
        client_dh = DiffieHellman()
        client_nonce = os.urandom(16)
        client_sig = sign_dh_exchange(self.client_key, client_dh.public_key, client_nonce)

        # 4. Send client's DH parameters
        send_message(
            self.sock,
            {
                "type": "session_dh",
                "dh_pub": client_dh.public_key,
                "nonce": b64_encode(client_nonce),
                "sig": b64_encode(client_sig),
            },
        )

        # 5. Derive 128-bit AES session key
        session_key = client_dh.derive_key(server_dh_pub)

        # 6. Wait for server confirmation
        ready_msg = recv_message(self.sock)
        if ready_msg.get("type") != "session_ready":
            print(f"[!] Server session ready failed: {ready_msg}")
            return False

        # Initialize session manager
        self.session = SecureChatSession(
            session_id=self.session_id,
            role="client",
            session_key=session_key,
            local_key=self.client_key,
            peer_cert=self.server_cert,
            transcripts_dir="transcripts",
        )

        print("[+] Session key derived successfully! (AES-128-CBC + PKCS#7 + RSA-SHA256 Signatures active)")
        self.is_connected = True
        return True

    def _receive_loop(self) -> None:
        """Background thread receiving messages and performing data plane verification."""
        while self.is_connected:
            try:
                msg = recv_message(self.sock)
                msg_type = msg.get("type")

                if msg_type == "msg":
                    success, code, result = self.session.process_incoming_message(msg)
                    if success:
                        print(f"\n{result}\n> ", end="", flush=True)
                    else:
                        print(f"\n[ALERT] Rejected incoming message: {code} - {result}\n> ", end="", flush=True)

                elif msg_type == "error":
                    print(f"\n[SERVER REJECTION] {msg.get('code')}: {msg.get('message')}\n> ", end="", flush=True)

                elif msg_type == "receipt_exchange":
                    receipt_for_peer = msg.get("receipt_for_peer")
                    if receipt_for_peer:
                        path = self.session.transcript.save_receipt(
                            receipt_for_peer,
                            filename=f"{self.session_id}_client_peer_receipt.json",
                        )
                        print(f"\n[+] Saved Server-signed SessionReceipt to: {path}\n> ", end="", flush=True)

                    server_summary = msg.get("server_summary", {})
                    if server_summary and "transcript_sha256" in server_summary:
                        client_signed_pkg = self.session.transcript.generate_receipt(
                            signer_key=self.client_key,
                            peer_name="server",
                            override_hash=server_summary.get("transcript_sha256"),
                            override_first_seq=server_summary.get("first_seq"),
                            override_last_seq=server_summary.get("last_seq"),
                        )
                        send_message(self.sock, {"type": "receipt_ack", "receipt_pkg": client_signed_pkg})

            except ConnectionClosedError:
                if self.is_connected:
                    print("\n[!] Server closed connection.", flush=True)
                break
            except Exception as e:
                if self.is_connected:
                    print(f"\n[!] Error in receive loop: {e}", flush=True)
                break

    def run_chat_ui(self) -> None:
        """Start interactive CLI chat session with concurrent sender and receiver."""
        print("=" * 60)
        print(f"      SecureChat Active Room | User: {self.username}")
        print("      Type your message and press ENTER to send.")
        print("      Type '/quit' to safely exit and generate non-repudiation receipts.")
        print("=" * 60)

        recv_thread = threading.Thread(target=self._receive_loop, daemon=True)
        recv_thread.start()

        try:
            while self.is_connected:
                text = input("> ")
                if not text.strip():
                    continue

                if text.strip() == "/quit":
                    print("[*] Terminating chat session...")
                    # Save local client receipt
                    local_receipt = self.session.transcript.generate_receipt(
                        signer_key=self.client_key,
                        peer_name="server",
                    )
                    path = self.session.transcript.save_receipt(local_receipt)
                    print(f"[+] Generated and signed local Client SessionReceipt: {path}")

                    # Send quit with peer summary for mutual non-repudiation signing
                    first_seq = self.session.transcript.first_seq or 0
                    last_seq = self.session.transcript.last_seq or 0
                    t_hash = self.session.transcript.compute_transcript_hash()
                    send_message(
                        self.sock,
                        {
                            "type": "quit",
                            "peer_summary": {
                                "first_seq": first_seq,
                                "last_seq": last_seq,
                                "transcript_sha256": t_hash,
                            },
                        },
                    )
                    time.sleep(0.8)  # allow receiver loop to handle mutual receipt exchange
                    self.is_connected = False
                    break

                # Create AES-encrypted, SHA-256 hashed, and RSA-signed message
                msg = self.session.create_message(text)
                send_message(self.sock, msg)

        except (KeyboardInterrupt, EOFError):
            print("\n[*] Exiting chat session...")
        finally:
            self.is_connected = False
            if self.sock:
                try:
                    self.sock.close()
                except Exception:
                    pass
            print("[+] Session closed. Cryptographic transcripts flushed.")


def main() -> None:
    parser = argparse.ArgumentParser(description="SecureChat CLI Client.")
    parser.add_argument("--user", help="Client username / identity (e.g. alice, bob)")
    parser.add_argument("--host", default=os.getenv("SERVER_HOST", "127.0.0.1"), help="Server host")
    parser.add_argument("--port", type=int, default=int(os.getenv("SERVER_PORT", "8443")), help="Server port")
    args = parser.parse_args()

    user = args.user
    if not user:
        user = input("Enter client username (e.g. alice, bob): ").strip()
        if not user:
            print("[!] Username cannot be empty.")
            sys.exit(1)

    try:
        client = SecureChatClient(username=user, host=args.host, port=args.port)
    except FileNotFoundError as e:
        print(f"[!] Configuration Error: {e}")
        sys.exit(1)

    if not client.connect():
        sys.exit(1)

    # Interactive Authentication Menu
    while True:
        print("\n--- Authentication Menu ---")
        print("1. Login")
        print("2. Register new account")
        print("3. Exit")
        choice = input("Select an option (1-3): ").strip()

        if choice == "1":
            pwd = getpass.getpass("Enter password: ")
            if client.login(pwd):
                if client.establish_session_key():
                    client.run_chat_ui()
                break
        elif choice == "2":
            email = input("Enter email address: ").strip()
            pwd = getpass.getpass("Enter new password: ")
            pwd_confirm = getpass.getpass("Confirm password: ")
            if pwd != pwd_confirm:
                print("[!] Passwords do not match.")
                continue
            client.register(email, pwd)
        elif choice == "3":
            print("[*] Goodbye.")
            if client.sock:
                client.sock.close()
            sys.exit(0)
        else:
            print("[!] Invalid option. Please choose 1, 2, or 3.")


if __name__ == "__main__":
    main()
