"""Cryptographic modules for PKI, Diffie-Hellman, AES, and RSA signatures."""
