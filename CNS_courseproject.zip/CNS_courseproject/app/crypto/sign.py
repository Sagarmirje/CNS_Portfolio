"""
Digital signature and hashing module.
Implements SHA-256 message hashing and RSA signing/verifying with PKCS#1 v1.5.
"""

import hashlib
from typing import Union

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa, utils


class SignatureVerificationError(Exception):
    """Raised when an RSA digital signature fails verification."""
    pass


def sha256_digest(data: Union[bytes, str]) -> bytes:
    """Compute the raw 32-byte SHA-256 digest of data."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).digest()


def compute_message_hash(seqno: int, ts: int, ct_b64: str) -> bytes:
    """
    Compute h = SHA-256(str(seqno) || str(ts) || ct).
    Input ct is the base64-encoded ciphertext string from the message frame.
    """
    raw_payload = f"{seqno}{ts}{ct_b64}".encode("utf-8")
    return hashlib.sha256(raw_payload).digest()


def sign_hash(private_key: rsa.RSAPrivateKey, digest: bytes) -> bytes:
    """
    Sign a precomputed 32-byte SHA-256 digest with an RSA private key using PKCS#1 v1.5.
    """
    if len(digest) != 32:
        raise ValueError(f"Expected 32-byte SHA-256 digest, got {len(digest)} bytes.")
    return private_key.sign(
        digest,
        padding.PKCS1v15(),
        utils.Prehashed(hashes.SHA256()),
    )


def verify_hash(public_key: rsa.RSAPublicKey, digest: bytes, signature: bytes) -> bool:
    """
    Verify an RSA signature against a 32-byte SHA-256 digest using PKCS#1 v1.5.
    Raises SignatureVerificationError if invalid.
    """
    if len(digest) != 32:
        raise ValueError(f"Expected 32-byte SHA-256 digest, got {len(digest)} bytes.")
    try:
        public_key.verify(
            signature,
            digest,
            padding.PKCS1v15(),
            utils.Prehashed(hashes.SHA256()),
        )
        return True
    except InvalidSignature:
        raise SignatureVerificationError("RSA signature verification failed.")
    except Exception as e:
        raise SignatureVerificationError(f"Verification error: {e}")


def sign_data(private_key: rsa.RSAPrivateKey, data: Union[bytes, str]) -> bytes:
    """Hash data with SHA-256 and sign with RSA private key."""
    digest = sha256_digest(data)
    return sign_hash(private_key, digest)


def verify_data(public_key: rsa.RSAPublicKey, data: Union[bytes, str], signature: bytes) -> bool:
    """Hash data with SHA-256 and verify RSA signature."""
    digest = sha256_digest(data)
    return verify_hash(public_key, digest, signature)
