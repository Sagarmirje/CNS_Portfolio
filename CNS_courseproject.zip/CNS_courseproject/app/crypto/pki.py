"""PKI and X.509 Certificate validation and helper utilities."""

import datetime
from typing import Optional, Union

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


class PKIValidationError(Exception):
    """Base exception for PKI validation errors."""
    pass


class BAD_CERT_SIGNATURE(PKIValidationError):
    """Raised when certificate signature cannot be verified by Root CA."""
    pass


class CERT_EXPIRED(PKIValidationError):
    """Raised when certificate is not within its validity window."""
    pass


class CERT_CN_MISMATCH(PKIValidationError):
    """Raised when certificate Common Name does not match expected identity."""
    pass


class UNTRUSTED_ISSUER(PKIValidationError):
    """Raised when certificate issuer is untrusted or self-signed by unauthorized party."""
    pass


def load_certificate(cert_data: Union[str, bytes, x509.Certificate]) -> x509.Certificate:
    """Load an X.509 certificate from PEM string, bytes, or return if already parsed."""
    if isinstance(cert_data, x509.Certificate):
        return cert_data
    if isinstance(cert_data, str):
        cert_bytes = cert_data.encode("utf-8")
    else:
        cert_bytes = cert_data
    return x509.load_pem_x509_certificate(cert_bytes)


def load_private_key(key_data: Union[str, bytes], password: Optional[bytes] = None) -> rsa.RSAPrivateKey:
    """Load an RSA private key from PEM string or bytes."""
    if isinstance(key_data, str):
        key_bytes = key_data.encode("utf-8")
    else:
        key_bytes = key_data
    key = serialization.load_pem_private_key(key_bytes, password=password)
    if not isinstance(key, rsa.RSAPrivateKey):
        raise ValueError("Loaded key is not an RSA private key.")
    return key


def certificate_to_pem(cert: x509.Certificate) -> str:
    """Serialize an X.509 certificate to PEM string."""
    return cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")


def private_key_to_pem(key: rsa.RSAPrivateKey, password: Optional[bytes] = None) -> str:
    """Serialize an RSA private key to PEM string."""
    encryption_algorithm: serialization.KeySerializationEncryption
    if password:
        encryption_algorithm = serialization.BestAvailableEncryption(password)
    else:
        encryption_algorithm = serialization.NoEncryption()
    return key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=encryption_algorithm,
    ).decode("utf-8")


def get_certificate_cn(cert: x509.Certificate) -> str:
    """Extract Common Name (CN) from certificate subject."""
    cn_attrs = cert.subject.get_attributes_for_oid(x509.NameOID.COMMON_NAME)
    if not cn_attrs:
        return ""
    return str(cn_attrs[0].value)


def get_certificate_fingerprint(cert: Union[x509.Certificate, str, bytes]) -> str:
    """Compute hex-encoded SHA-256 fingerprint of certificate DER bytes."""
    cert_obj = load_certificate(cert)
    digest = cert_obj.fingerprint(hashes.SHA256())
    return digest.hex()


def validate_certificate(
    cert_data: Union[str, bytes, x509.Certificate],
    ca_cert_data: Union[str, bytes, x509.Certificate],
    expected_cn: Optional[str] = None,
) -> bool:
    """
    Validate certificate against the Root CA.

    Checks performed in order:
    1. Issuer check (must match CA subject and not be self-signed by unauthorized party).
    2. Cryptographic signature check by Root CA public key.
    3. Validity time window check (not before, not after).
    4. Expected Common Name (CN) check (if expected_cn is supplied).

    Raises:
        UNTRUSTED_ISSUER
        BAD_CERT_SIGNATURE
        CERT_EXPIRED
        CERT_CN_MISMATCH
    Returns:
        True if all checks succeed.
    """
    cert = load_certificate(cert_data)
    ca_cert = load_certificate(ca_cert_data)

    # 1. Check issuer matching CA subject
    if cert.issuer != ca_cert.subject:
        raise UNTRUSTED_ISSUER(
            f"Certificate issuer '{cert.issuer.rfc4514_string()}' does not match "
            f"Root CA subject '{ca_cert.subject.rfc4514_string()}'."
        )

    # Check if cert is self-signed but not the trusted CA itself
    if cert.issuer == cert.subject:
        if cert.fingerprint(hashes.SHA256()) != ca_cert.fingerprint(hashes.SHA256()):
            raise UNTRUSTED_ISSUER("Certificate is self-signed and does not match the trusted Root CA.")

    # 2. Cryptographic signature verification using Root CA public key
    ca_public_key = ca_cert.public_key()
    if not isinstance(ca_public_key, rsa.RSAPublicKey):
        raise UNTRUSTED_ISSUER("Root CA public key is not an RSA public key.")

    try:
        ca_public_key.verify(
            cert.signature,
            cert.tbs_certificate_bytes,
            padding.PKCS1v15(),
            cert.signature_hash_algorithm,
        )
    except InvalidSignature:
        raise BAD_CERT_SIGNATURE("Certificate signature verification failed against Root CA public key.")
    except Exception as e:
        raise BAD_CERT_SIGNATURE(f"Certificate signature verification error: {e}")

    # 3. Validity dates check
    now = datetime.datetime.now(datetime.timezone.utc)
    # Support both not_valid_before_utc (cryptography >= 42) and legacy fallback
    try:
        not_before = cert.not_valid_before_utc
        not_after = cert.not_valid_after_utc
    except AttributeError:
        not_before = cert.not_valid_before.replace(tzinfo=datetime.timezone.utc)
        not_after = cert.not_valid_after.replace(tzinfo=datetime.timezone.utc)

    if now < not_before or now > not_after:
        raise CERT_EXPIRED(
            f"Certificate validity expired or not yet valid. Valid from {not_before} to {not_after}, current UTC: {now}"
        )

    # 4. Expected Common Name check
    if expected_cn is not None:
        cert_cn = get_certificate_cn(cert)
        if cert_cn != expected_cn:
            raise CERT_CN_MISMATCH(
                f"Certificate CN '{cert_cn}' does not match expected CN '{expected_cn}'."
            )

    return True
