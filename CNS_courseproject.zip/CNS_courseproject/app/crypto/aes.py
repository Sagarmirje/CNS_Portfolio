"""
AES-128 Encryption & Decryption module using CBC mode with PKCS#7 padding.
A fresh, cryptographically secure 16-byte IV is generated per encryption and prepended.
"""

import os
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


class AESError(Exception):
    """Base exception for AES operations."""
    pass


class AESDecryptionError(AESError):
    """Raised when AES decryption or PKCS#7 unpadding fails."""
    pass


def encrypt_aes_cbc(key: bytes, plaintext: bytes) -> bytes:
    """
    Encrypt plaintext with AES-128-CBC and PKCS#7 padding.
    Generates a random 16-byte IV and prepends it to the resulting ciphertext.
    Returns: iv (16 bytes) + ciphertext.
    """
    if len(key) != 16:
        raise ValueError(f"AES-128 requires a 16-byte key, got {len(key)} bytes.")

    # 1. Apply PKCS#7 padding (128-bit block size)
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plaintext) + padder.finalize()

    # 2. Generate random 16-byte IV
    iv = os.urandom(16)

    # 3. Encrypt in CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()

    # 4. Prepend IV
    return iv + ciphertext


def decrypt_aes_cbc(key: bytes, encrypted_payload: bytes) -> bytes:
    """
    Decrypt payload (iv + ciphertext) with AES-128-CBC and remove PKCS#7 padding.
    Raises AESDecryptionError on corrupted payload, bad length, or invalid padding.
    """
    if len(key) != 16:
        raise ValueError(f"AES-128 requires a 16-byte key, got {len(key)} bytes.")

    if len(encrypted_payload) < 32 or (len(encrypted_payload) - 16) % 16 != 0:
        raise AESDecryptionError(
            f"Invalid ciphertext length: {len(encrypted_payload)} bytes. Must include 16-byte IV and block-aligned ciphertext."
        )

    iv = encrypted_payload[:16]
    ciphertext = encrypted_payload[16:]

    try:
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        decryptor = cipher.decryptor()
        padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

        unpadder = padding.PKCS7(128).unpadder()
        plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
        return plaintext
    except ValueError as e:
        raise AESDecryptionError(f"PKCS#7 unpadding failed: {e}")
    except Exception as e:
        raise AESDecryptionError(f"Decryption failed: {e}")
