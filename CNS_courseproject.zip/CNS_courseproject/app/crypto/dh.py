"""
Diffie-Hellman Key Exchange based on RFC 3526 2048-bit MODP Group 14 (Generator 2).
Provides authenticated DH exchange and 128-bit AES key derivation:
K = Trunc16(SHA-256(big_endian(shared_secret)))
"""

import hashlib
import os
import secrets
from typing import Tuple

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa

# RFC 3526 - 2048-bit MODP Group 14
RFC3526_2048_MODP_HEX = (
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
    "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
    "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
    "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF"
)

DH_P = int(RFC3526_2048_MODP_HEX, 16)
DH_G = 2
KEY_SIZE_BYTES = 256  # 2048 bits = 256 bytes


class DHValidationError(Exception):
    """Raised when DH parameters or peer public values are invalid."""
    pass


class DHAuthError(Exception):
    """Raised when authenticated DH signature verification fails."""
    pass


class DiffieHellman:
    """Manages an ephemeral Diffie-Hellman key exchange session."""

    def __init__(self, p: int = DH_P, g: int = DH_G):
        self.p = p
        self.g = g
        # Ephemeral private key: 2 <= x <= p - 2
        # Use 256-bit or full-width cryptographically secure random value
        self._private_key: int = secrets.randbelow(self.p - 3) + 2
        self.public_key: int = pow(self.g, self._private_key, self.p)

    def validate_peer_public(self, peer_public: int) -> None:
        """Validate DH public value: must strictly satisfy 1 < y < p - 1."""
        if not isinstance(peer_public, int):
            raise DHValidationError("Peer DH public value must be an integer.")
        if peer_public <= 1 or peer_public >= (self.p - 1):
            raise DHValidationError(
                f"Peer public key fails range check: 1 < y < p - 1. (Got {peer_public})"
            )

    def compute_shared_secret(self, peer_public: int) -> int:
        """Compute the raw shared secret s = (peer_public ^ private_key) mod p."""
        self.validate_peer_public(peer_public)
        return pow(peer_public, self._private_key, self.p)

    def derive_key(self, peer_public: int) -> bytes:
        """
        Derive 128-bit AES session key K:
        K = Trunc16(SHA-256(big_endian(shared_secret)))
        """
        shared_secret = self.compute_shared_secret(peer_public)
        secret_bytes = shared_secret.to_bytes(KEY_SIZE_BYTES, byteorder="big")
        derived_digest = hashlib.sha256(secret_bytes).digest()
        return derived_digest[:16]


def sign_dh_exchange(
    private_key: rsa.RSAPrivateKey,
    dh_public: int,
    nonce: bytes,
) -> bytes:
    """
    Sign DH public value and nonce with party's RSA private key:
    data_to_sign = big_endian(dh_public) || nonce
    """
    dh_bytes = dh_public.to_bytes(KEY_SIZE_BYTES, byteorder="big")
    payload = dh_bytes + nonce
    signature = private_key.sign(
        payload,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )
    return signature


def verify_dh_exchange(
    public_key: rsa.RSAPublicKey,
    dh_public: int,
    nonce: bytes,
    signature: bytes,
) -> bool:
    """
    Verify peer's RSA signature on DH public value and nonce.
    Raises DHAuthError on failure.
    """
    dh_bytes = dh_public.to_bytes(KEY_SIZE_BYTES, byteorder="big")
    payload = dh_bytes + nonce
    try:
        public_key.verify(
            signature,
            payload,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH,
            ),
            hashes.SHA256(),
        )
        return True
    except InvalidSignature:
        raise DHAuthError("Diffie-Hellman exchange signature verification failed.")
    except Exception as e:
        raise DHAuthError(f"Diffie-Hellman verification error: {e}")
