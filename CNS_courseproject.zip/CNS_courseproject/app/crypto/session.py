"""
SecureChat Session Engine.
Encapsulates session state, key agreement derivation, message creation,
ordered 4-step receiver verification, and transcript logging.
"""

from typing import Any, Dict, Optional, Tuple

from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import rsa

from app.common.utils import b64_decode, b64_encode, now_ms
from app.crypto.aes import AESDecryptionError, decrypt_aes_cbc, encrypt_aes_cbc
from app.crypto.sign import (
    SignatureVerificationError,
    compute_message_hash,
    sign_hash,
    verify_hash,
)
from app.storage.transcript import TranscriptLogger


class SessionSecurityError(Exception):
    """Raised when session verification fails."""
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class SecureChatSession:
    """
    Manages an active end-to-end encrypted chat session between two authenticated peers.
    Enforces ordered data plane verification:
      1. Replay prevention (seqno > last_seqno)
      2. Freshness check (|ts - now| <= window)
      3. RSA signature verification
      4. AES-128-CBC PKCS#7 decryption
    """

    def __init__(
        self,
        session_id: str,
        role: str,
        session_key: bytes,
        local_key: rsa.RSAPrivateKey,
        peer_cert: x509.Certificate,
        time_window_ms: int = 60000,  # 60 seconds
        transcripts_dir: str = "transcripts",
    ):
        if len(session_key) != 16:
            raise ValueError(f"Session key must be 16 bytes for AES-128, got {len(session_key)}.")

        self.session_id = session_id
        self.role = role.lower()
        self.session_key = session_key
        self.local_key = local_key
        self.peer_cert = peer_cert
        self.peer_pubkey = peer_cert.public_key()
        if not isinstance(self.peer_pubkey, rsa.RSAPublicKey):
            raise ValueError("Peer certificate public key is not an RSA public key.")

        self.time_window_ms = time_window_ms
        self.my_seqno = 0
        self.last_seqno = 0

        self.transcript = TranscriptLogger(
            session_id=session_id,
            role=role,
            peer_cert=peer_cert,
            transcripts_dir=transcripts_dir,
        )

    def create_message(self, plaintext: str) -> Dict[str, Any]:
        """
        Produce a protected message dictionary:
        { "type": "msg", "seqno": int, "ts": unix_ms, "ct": base64, "sig": base64 }
        """
        self.my_seqno += 1
        seqno = self.my_seqno
        ts = now_ms()

        # 1. AES-128-CBC encrypt with prepended 16-byte random IV & PKCS#7 padding
        ct_bytes = encrypt_aes_cbc(self.session_key, plaintext.encode("utf-8"))
        ct_b64 = b64_encode(ct_bytes)

        # 2. Compute message hash h = SHA-256(str(seqno) || str(ts) || ct)
        digest = compute_message_hash(seqno, ts, ct_b64)

        # 3. RSA sign hash with sender's private key
        sig_bytes = sign_hash(self.local_key, digest)
        sig_b64 = b64_encode(sig_bytes)

        return {
            "type": "msg",
            "seqno": seqno,
            "ts": ts,
            "ct": ct_b64,
            "sig": sig_b64,
        }

    def process_incoming_message(
        self,
        msg: Dict[str, Any],
        override_now_ms: Optional[int] = None,
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Process incoming message enforcing the strict 4-step security checks:
          1. seqno > last_seqno -> REPLAY
          2. |ts - now| <= window -> STALE
          3. RSA signature verification -> SIG_FAIL
          4. AES decryption -> DECRYPT_FAIL

        Returns:
          (True, "OK", plaintext) on success
          (False, code, error_description) on rejection
        """
        if not isinstance(msg, dict) or msg.get("type") != "msg":
            return False, "INVALID_FRAME", "Malformed message frame."

        seqno = msg.get("seqno")
        ts = msg.get("ts")
        ct_b64 = msg.get("ct")
        sig_b64 = msg.get("sig")

        if not all(isinstance(x, (int, str)) for x in (seqno, ts, ct_b64, sig_b64)):
            return False, "INVALID_FIELDS", "Missing or invalid message fields."

        # 1. Check sequence number is strictly greater than last accepted (prevent replay/reorder)
        if seqno <= self.last_seqno:
            return (
                False,
                "REPLAY",
                f"Replay detected: seqno {seqno} is not greater than last accepted {self.last_seqno}.",
            )

        # 2. Check timestamp is within allowed window (+/- 60 seconds)
        current_time = override_now_ms if override_now_ms is not None else now_ms()
        if abs(current_time - ts) > self.time_window_ms:
            return (
                False,
                "STALE",
                f"Stale message: timestamp {ts} is outside the allowed +/- {self.time_window_ms}ms window (now: {current_time}).",
            )

        # 3. Recompute h and verify RSA signature with peer's public key
        digest = compute_message_hash(seqno, ts, ct_b64)
        try:
            sig_bytes = b64_decode(sig_b64)
            verify_hash(self.peer_pubkey, digest, sig_bytes)
        except SignatureVerificationError:
            return False, "SIG_FAIL", "Digital signature verification failed (tampering detected)."
        except Exception as e:
            return False, "SIG_FAIL", f"Signature decoding or verification error: {e}"

        # 4. Decrypt ciphertext with AES-128-CBC and PKCS#7 unpadding
        try:
            ct_bytes = b64_decode(ct_b64)
            pt_bytes = decrypt_aes_cbc(self.session_key, ct_bytes)
            plaintext = pt_bytes.decode("utf-8")
        except AESDecryptionError as e:
            return False, "DECRYPT_FAIL", f"AES decryption or unpadding failed: {e}"
        except Exception as e:
            return False, "DECRYPT_FAIL", f"Payload decoding failed: {e}"

        # Message fully accepted: update state and append to transcript
        self.last_seqno = seqno
        self.transcript.log_message(seqno, ts, ct_b64, sig_b64)
        return True, "OK", plaintext
