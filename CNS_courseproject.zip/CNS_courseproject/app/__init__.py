"""SecureChat application package."""
