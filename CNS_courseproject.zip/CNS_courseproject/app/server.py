"""
SecureChat Multi-client TCP Server.
Handles concurrent clients with isolated cryptographic session state,
mutual TLS-like certificate exchange, ephemeral DH credentials protection,
authenticated session key agreement, encrypted chat routing, and SessionReceipt exchange.
"""

import argparse
import json
import logging
import os
import socket
import sys
import threading
import uuid
from typing import Dict, Optional

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.common.protocol import (
    ConnectionClosedError,
    ProtocolError,
    recv_message,
    send_message,
)
from app.common.utils import b64_decode, b64_encode, now_ms
from app.crypto.aes import decrypt_aes_cbc, encrypt_aes_cbc
from app.crypto.dh import (
    DiffieHellman,
    sign_dh_exchange,
    verify_dh_exchange,
)
from app.crypto.pki import (
    PKIValidationError,
    certificate_to_pem,
    get_certificate_cn,
    load_certificate,
    load_private_key,
    validate_certificate,
)
from app.crypto.session import SecureChatSession
from app.storage.db import DatabaseManager

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [%(threadName)s] %(message)s",
)
logger = logging.getLogger("securechat.server")


class ClientHandler(threading.Thread):
    """Handles an individual connected client session."""

    def __init__(
        self,
        sock: socket.socket,
        addr: tuple,
        server: "SecureChatServer",
    ):
        super().__init__(name=f"Client-{addr[0]}:{addr[1]}")
        self.sock = sock
        self.addr = addr
        self.server = server
        self.session_id = str(uuid.uuid4())[:8]
        self.authenticated_user: Optional[str] = None
        self.client_cert = None
        self.session: Optional[SecureChatSession] = None
        self.is_running = True

    def run(self) -> None:
        try:
            logger.info("New connection from %s:%s (Session ID: %s)", self.addr[0], self.addr[1], self.session_id)
            # Step 1 & 2: Mutual Certificate Exchange & Validation
            if not self._do_handshake():
                return

            # Step 3: Temporary DH Exchange & Encrypted Auth (Register / Login)
            if not self._do_auth():
                return

            # Step 4 & 5: Authenticated Session Key Agreement (Chat Session)
            if not self._do_session_key_agreement():
                return

            # Step 6 & 7: Data Plane (Chat Message Loop)
            self.server.register_active_session(self.authenticated_user, self)
            self._chat_loop()

        except ConnectionClosedError:
            logger.info("Connection closed by peer %s.", self.authenticated_user or self.addr)
        except Exception as e:
            logger.error("Unhandled error in client session %s: %s", self.addr, e, exc_info=True)
        finally:
            self._cleanup()

    def _do_handshake(self) -> bool:
        """Exchange and validate X.509 certificates against Root CA."""
        # 1. Receive client certificate
        msg = recv_message(self.sock)
        if msg.get("type") != "handshake" or "cert" not in msg:
            logger.warning("Invalid handshake message from %s", self.addr)
            send_message(self.sock, {"type": "error", "code": "HANDSHAKE_FAIL", "message": "Expected handshake"})
            return False

        client_cert_pem = msg["cert"]
        try:
            validate_certificate(client_cert_pem, self.server.ca_cert)
            self.client_cert = load_certificate(client_cert_pem)
            cert_cn = get_certificate_cn(self.client_cert)
            logger.info("Client certificate successfully validated against Root CA (CN: %s).", cert_cn)
        except PKIValidationError as e:
            logger.warning("Peer certificate validation failed: %s (%s)", e.__class__.__name__, e)
            send_message(self.sock, {"type": "error", "code": e.__class__.__name__, "message": str(e)})
            return False

        # 2. Send server certificate
        server_cert_pem = certificate_to_pem(self.server.server_cert)
        send_message(self.sock, {"type": "handshake", "cert": server_cert_pem})
        return True

    def _do_auth(self) -> bool:
        """
        Run temporary Diffie-Hellman exchange to derive ephemeral AES key K_temp,
        then handle encrypted registration or login.
        """
        # Step 3a: Receive client temporary DH public value
        msg = recv_message(self.sock)
        if msg.get("type") != "dh_init" or "dh_pub" not in msg:
            logger.warning("Expected dh_init from %s", self.addr)
            send_message(self.sock, {"type": "error", "code": "AUTH_DH_FAIL", "message": "Expected dh_init"})
            return False

        client_dh_pub = int(msg["dh_pub"])
        temp_dh = DiffieHellman()
        try:
            temp_key = temp_dh.derive_key(client_dh_pub)
        except Exception as e:
            logger.warning("Temporary DH derivation failed: %s", e)
            send_message(self.sock, {"type": "error", "code": "AUTH_DH_FAIL", "message": str(e)})
            return False

        # Send server's temporary DH public value
        send_message(self.sock, {"type": "dh_init", "dh_pub": temp_dh.public_key})

        # Step 3b: Loop until successful login or disconnection
        while True:
            auth_msg = recv_message(self.sock)
            if auth_msg.get("type") != "auth_req" or "ct" not in auth_msg:
                send_message(self.sock, {"type": "error", "code": "AUTH_FAIL", "message": "Expected encrypted auth_req"})
                return False

            # Decrypt payload using temp_key
            try:
                ct_bytes = b64_decode(auth_msg["ct"])
                pt_bytes = decrypt_aes_cbc(temp_key, ct_bytes)
                cred_payload = json.loads(pt_bytes.decode("utf-8"))
            except Exception as e:
                logger.warning("Failed to decrypt credentials from %s: %s", self.addr, e)
                send_message(self.sock, {"type": "auth_resp", "status": "ERROR", "msg": "Decryption failed"})
                return False

            action = cred_payload.get("action")
            username = cred_payload.get("username", "")
            password = cred_payload.get("password", "")
            email = cred_payload.get("email", "")

            # Security: Never log passwords
            logger.info("Received encrypted auth request: action='%s', user='%s'", action, username)

            if action == "register":
                cert_cn = get_certificate_cn(self.client_cert)
                if cert_cn.lower() != username.lower():
                    resp = {"status": "CERT_CN_MISMATCH", "msg": "Certificate CN must match the registration username"}
                else:
                    success, status = self.server.db.register_user(email, username, password)
                    if success:
                        resp = {"status": "OK", "msg": "Registration successful. Please log in."}
                    else:
                        resp = {"status": status, "msg": f"Registration failed: {status}"}

                # Send encrypted response
                resp_bytes = json.dumps(resp).encode("utf-8")
                resp_ct = b64_encode(encrypt_aes_cbc(temp_key, resp_bytes))
                send_message(self.sock, {"type": "auth_resp", "ct": resp_ct})

            elif action == "login":
                # Verify certificate CN matches username
                cert_cn = get_certificate_cn(self.client_cert)
                if cert_cn.lower() != username.lower():
                    logger.warning(
                        "Authentication rejected: Certificate CN '%s' does not match claimed username '%s'.",
                        cert_cn,
                        username,
                    )
                    resp = {"status": "CERT_CN_MISMATCH", "msg": "Certificate CN does not match username"}
                    resp_bytes = json.dumps(resp).encode("utf-8")
                    resp_ct = b64_encode(encrypt_aes_cbc(temp_key, resp_bytes))
                    send_message(self.sock, {"type": "auth_resp", "ct": resp_ct})
                    continue

                success, status = self.server.db.verify_user(username, password)
                if success:
                    self.authenticated_user = username
                    resp = {"status": "OK", "msg": "Login successful"}
                    resp_bytes = json.dumps(resp).encode("utf-8")
                    resp_ct = b64_encode(encrypt_aes_cbc(temp_key, resp_bytes))
                    send_message(self.sock, {"type": "auth_resp", "ct": resp_ct})
                    logger.info("User '%s' authenticated successfully.", username)
                    return True
                else:
                    resp = {"status": "BAD_CREDENTIALS", "msg": "Invalid username or password"}
                    resp_bytes = json.dumps(resp).encode("utf-8")
                    resp_ct = b64_encode(encrypt_aes_cbc(temp_key, resp_bytes))
                    send_message(self.sock, {"type": "auth_resp", "ct": resp_ct})
            else:
                resp = {"status": "ERROR", "msg": "Unknown action"}
                resp_bytes = json.dumps(resp).encode("utf-8")
                resp_ct = b64_encode(encrypt_aes_cbc(temp_key, resp_bytes))
                send_message(self.sock, {"type": "auth_resp", "ct": resp_ct})

    def _do_session_key_agreement(self) -> bool:
        """
        Step 4 & 5: Run fresh ephemeral authenticated Diffie-Hellman exchange.
        Each party signs (dh_pub || nonce) with their RSA private key.
        Derive K_session = Trunc16(SHA-256(big_endian(shared_secret))).
        """
        logger.info("Initiating fresh authenticated DH key agreement for %s...", self.authenticated_user)
        session_dh = DiffieHellman()
        server_nonce = os.urandom(16)
        server_sig = sign_dh_exchange(self.server.server_key, session_dh.public_key, server_nonce)

        # 1. Send server's DH parameters
        send_message(
            self.sock,
            {
                "type": "session_dh",
                "dh_pub": session_dh.public_key,
                "nonce": b64_encode(server_nonce),
                "sig": b64_encode(server_sig),
            },
        )

        # 2. Receive client's DH parameters
        client_msg = recv_message(self.sock)
        if client_msg.get("type") != "session_dh":
            logger.warning("Expected session_dh from %s", self.authenticated_user)
            return False

        client_dh_pub = int(client_msg["dh_pub"])
        client_nonce = b64_decode(client_msg["nonce"])
        client_sig = b64_decode(client_msg["sig"])

        # Verify client's RSA signature over client's DH public value and nonce
        try:
            verify_dh_exchange(
                self.client_cert.public_key(),
                client_dh_pub,
                client_nonce,
                client_sig,
            )
            logger.info("Client's DH exchange signature verified with client certificate public key.")
        except Exception as e:
            logger.warning("Peer DH signature verification failed: %s", e)
            send_message(self.sock, {"type": "error", "code": "DH_AUTH_FAIL", "message": "DH signature invalid"})
            return False

        # Derive 128-bit AES session key
        session_key = session_dh.derive_key(client_dh_pub)

        # Initialize SecureChatSession
        self.session = SecureChatSession(
            session_id=self.session_id,
            role="server",
            session_key=session_key,
            local_key=self.server.server_key,
            peer_cert=self.client_cert,
            transcripts_dir="transcripts",
        )

        send_message(self.sock, {"type": "session_ready", "status": "OK"})
        logger.info("Session key derived successfully for user '%s'. Entering chat state.", self.authenticated_user)
        return True

    def _chat_loop(self) -> None:
        """
        Step 6 & 7: Receive messages, perform 4-step security validation,
        log to transcript, and broadcast to active chat participants.
        """
        while self.is_running:
            msg = recv_message(self.sock)
            msg_type = msg.get("type")

            if msg_type == "quit":
                logger.info("User '%s' requested session termination (/quit).", self.authenticated_user)
                peer_summary = msg.get("peer_summary", {})
                self._handle_quit(peer_summary)
                break

            if msg_type == "msg":
                # Run strict 4-step receiver verification:
                # 1. seqno > last (REPLAY)
                # 2. freshness window (STALE)
                # 3. RSA signature verification (SIG_FAIL)
                # 4. AES decryption (DECRYPT_FAIL)
                success, code, result = self.session.process_incoming_message(msg)

                if not success:
                    logger.warning(
                        "Message from '%s' rejected! Reason: %s - %s",
                        self.authenticated_user,
                        code,
                        result,
                    )
                    send_message(self.sock, {"type": "error", "code": code, "message": result})
                    continue

                plaintext = result
                logger.info("Received valid message from '%s' (seq=%s): %s", self.authenticated_user, msg.get("seqno"), plaintext)

                # Broadcast to other connected clients
                self.server.broadcast(self.authenticated_user, plaintext, sender_handler=self)

            else:
                logger.warning("Unrecognized message type '%s' from '%s'", msg_type, self.authenticated_user)

    def send_chat_message(self, sender: str, text: str) -> None:
        """Send an encrypted, hashed, and signed message to this client."""
        if not self.session:
            return
        payload = f"[{sender}]: {text}"
        protected_msg = self.session.create_message(payload)
        send_message(self.sock, protected_msg)

    def _handle_quit(self, peer_summary: Optional[Dict] = None) -> None:
        """
        Step 8: Finalize transcript, sign peer's receipt request,
        request peer's signature on our transcript, and exchange.
        """
        if not self.session:
            return

        # 1. Sign peer's transcript summary if provided
        server_signed_receipt_for_peer = None
        if peer_summary and "transcript_sha256" in peer_summary:
            server_signed_receipt_for_peer = self.session.transcript.generate_receipt(
                signer_key=self.server.server_key,
                peer_name=self.authenticated_user,
                override_hash=peer_summary.get("transcript_sha256"),
                override_first_seq=peer_summary.get("first_seq"),
                override_last_seq=peer_summary.get("last_seq"),
            )

        # 2. Compute server's own transcript summary (messages received from client)
        server_hash = self.session.transcript.compute_transcript_hash()
        server_summary = {
            "first_seq": self.session.transcript.first_seq or 0,
            "last_seq": self.session.transcript.last_seq or 0,
            "transcript_sha256": server_hash,
        }

        # Also save local server receipt
        local_receipt = self.session.transcript.generate_receipt(
            signer_key=self.server.server_key,
            peer_name=self.authenticated_user,
        )
        self.session.transcript.save_receipt(local_receipt)

        # Send response to client
        send_message(
            self.sock,
            {
                "type": "receipt_exchange",
                "receipt_for_peer": server_signed_receipt_for_peer,
                "server_summary": server_summary,
            },
        )

        # 3. Wait for client to return signed receipt for server's transcript
        try:
            ack_msg = recv_message(self.sock)
            if ack_msg.get("type") == "receipt_ack":
                client_signed_pkg = ack_msg.get("receipt_pkg")
                if client_signed_pkg:
                    saved_peer_receipt = self.session.transcript.save_receipt(
                        client_signed_pkg,
                        filename=f"{self.session_id}_server_peer_receipt.json",
                    )
                    logger.info("Saved Client-signed SessionReceipt to: %s", saved_peer_receipt)
        except Exception as e:
            logger.warning("Could not receive client receipt acknowledgment: %s", e)

    def _cleanup(self) -> None:
        """Clean up sockets and unregister session."""
        self.is_running = False
        if self.authenticated_user:
            self.server.unregister_active_session(self.authenticated_user)
        try:
            self.sock.close()
        except Exception:
            pass
        logger.info("Connection handler for %s terminated.", self.authenticated_user or self.addr)


class SecureChatServer:
    """Main SecureChat TCP Server."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8443,
        ca_cert_path: str = "certs/ca.crt",
        server_cert_path: str = "certs/server.crt",
        server_key_path: str = "certs/server.key",
    ):
        self.host = host
        self.port = port
        self.ca_cert_path = ca_cert_path
        self.server_cert_path = server_cert_path
        self.server_key_path = server_key_path

        self.db = DatabaseManager()
        self._load_certificates()

        self.active_sessions: Dict[str, ClientHandler] = {}
        self.lock = threading.Lock()
        self.server_sock: Optional[socket.socket] = None
        self.is_running = True

    def _load_certificates(self) -> None:
        """Load Root CA certificate, server certificate, and server private key."""
        if not os.path.exists(self.ca_cert_path):
            raise FileNotFoundError(f"Root CA cert missing at {self.ca_cert_path}. Run scripts/gen_ca.py first.")
        if not os.path.exists(self.server_cert_path) or not os.path.exists(self.server_key_path):
            raise FileNotFoundError(
                f"Server cert/key missing at {self.server_cert_path}. Run scripts/gen_cert.py server server first."
            )

        with open(self.ca_cert_path, "rb") as f:
            self.ca_cert = load_certificate(f.read())
        with open(self.server_cert_path, "rb") as f:
            self.server_cert = load_certificate(f.read())
        with open(self.server_key_path, "rb") as f:
            self.server_key = load_private_key(f.read())

        logger.info("Loaded Root CA (%s) and Server Certificate (%s).", self.ca_cert_path, self.server_cert_path)

    def register_active_session(self, username: str, handler: ClientHandler) -> None:
        with self.lock:
            self.active_sessions[username] = handler
            logger.info("Active chat sessions: %s", list(self.active_sessions.keys()))

    def unregister_active_session(self, username: str) -> None:
        with self.lock:
            if username in self.active_sessions:
                del self.active_sessions[username]
                logger.info("User '%s' disconnected. Active sessions: %s", username, list(self.active_sessions.keys()))

    def broadcast(self, sender: str, text: str, sender_handler: Optional[ClientHandler] = None) -> None:
        """Broadcast message to all other active chat participants, or echo if only one."""
        with self.lock:
            recipients = [h for u, h in self.active_sessions.items() if h != sender_handler]

        if not recipients and sender_handler:
            # If sender is alone, echo back confirmation so sender sees it
            sender_handler.send_chat_message("Server", f"Message received: '{text}' (no other peers in room)")
            return

        for client in recipients:
            try:
                client.send_chat_message(sender, text)
            except Exception as e:
                logger.warning("Failed to send message to %s: %s", client.authenticated_user, e)

    def start(self) -> None:
        """Start listening for incoming TCP client connections."""
        self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_sock.bind((self.host, self.port))
        self.server_sock.listen(10)
        logger.info("SecureChat Server listening on %s:%s", self.host, self.port)

        try:
            while self.is_running:
                try:
                    client_sock, addr = self.server_sock.accept()
                except OSError:
                    if not self.is_running:
                        break
                    raise
                handler = ClientHandler(client_sock, addr, self)
                handler.daemon = True
                handler.start()
        except KeyboardInterrupt:
            logger.info("Server shutting down by user request...")
        finally:
            self.stop()

    def stop(self) -> None:
        self.is_running = False
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass
        logger.info("SecureChat Server stopped.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Start the SecureChat TCP Server.")
    parser.add_argument("--host", default=os.getenv("SERVER_HOST", "127.0.0.1"), help="Host to bind")
    parser.add_argument("--port", type=int, default=int(os.getenv("SERVER_PORT", "8443")), help="Port to listen")
    args = parser.parse_args()

    server = SecureChatServer(host=args.host, port=args.port)
    server.start()


if __name__ == "__main__":
    main()
