import pytest

from app import web_ui


def test_identity_list_includes_all_certificate_key_pairs(tmp_path, monkeypatch):
    monkeypatch.setattr(web_ui, "CLIENT_CERT_DIR", str(tmp_path))
    for name in ("alice", "charlie", "server", "ca"):
        (tmp_path / f"{name}.crt").write_text("certificate")
        (tmp_path / f"{name}.key").write_text("private key")
    (tmp_path / "orphan.crt").write_text("certificate without key")

    response = web_ui.app.test_client().get("/api/identities")

    assert response.status_code == 200
    assert response.get_json() == {"identities": ["alice", "charlie"]}


def test_dashboard_starts_with_authentication_view():
    response = web_ui.app.test_client().get("/")
    page = response.get_data(as_text=True)

    assert response.status_code == 200
    assert 'id="auth-screen"' in page
    assert 'id="main-workspace" class="container-fluid post-login d-none"' in page


@pytest.mark.parametrize("endpoint", ["/api/connect", "/api/auth"])
def test_identity_endpoints_reject_unsafe_usernames(endpoint):
    response = web_ui.app.test_client().post(
        endpoint,
        json={"username": "../outside"},
    )

    assert response.status_code == 400
    assert "Username must be" in response.get_json()["error"]
