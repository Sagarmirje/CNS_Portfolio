"""
Unit tests for evidence plane:
Transcript generation, SessionReceipt signing, and offline verification.
"""

import datetime
import json
import os
import shutil
import tempfile
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from app.common.utils import b64_encode, now_ms
from app.crypto.pki import certificate_to_pem
from app.crypto.sign import compute_message_hash, sign_hash
from app.storage.transcript import TranscriptLogger
from tools.verify_transcript import verify_offline_transcript


@pytest.fixture
def test_environment():
    temp_dir = tempfile.mkdtemp()
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .public_key(key.public_key())
        .serial_number(1)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(key, hashes.SHA256())
    )

    cert_path = os.path.join(temp_dir, "peer.crt")
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    yield temp_dir, key, cert, cert_path

    shutil.rmtree(temp_dir, ignore_errors=True)


def test_transcript_generation_and_offline_verification(test_environment):
    temp_dir, key, cert, cert_path = test_environment
    logger = TranscriptLogger("sess_123", "client", cert, transcripts_dir=temp_dir)

    # Log 3 valid messages signed with key
    for seq in range(1, 4):
        ts = now_ms() + seq
        ct_b64 = b64_encode(f"Ciphertext payload {seq}".encode("utf-8"))
        digest = compute_message_hash(seq, ts, ct_b64)
        sig_b64 = b64_encode(sign_hash(key, digest))
        logger.log_message(seq, ts, ct_b64, sig_b64)

    # Generate receipt signed by peer key
    receipt = logger.generate_receipt(key, peer_name="alice")
    receipt_path = logger.save_receipt(receipt)

    # Run offline verification -> must PASS
    result = verify_offline_transcript(logger.file_path, receipt_path, cert_path)
    assert result is True


def test_transcript_tampering_fails_verification(test_environment):
    temp_dir, key, cert, cert_path = test_environment
    logger = TranscriptLogger("sess_456", "client", cert, transcripts_dir=temp_dir)

    ts = now_ms()
    ct_b64 = b64_encode(b"Original message")
    digest = compute_message_hash(1, ts, ct_b64)
    sig_b64 = b64_encode(sign_hash(key, digest))
    logger.log_message(1, ts, ct_b64, sig_b64)

    receipt = logger.generate_receipt(key, peer_name="alice")
    receipt_path = logger.save_receipt(receipt)

    # Tamper with transcript log file by changing characters in the log line
    with open(logger.file_path, "r", encoding="utf-8") as f:
        content = f.read()
    # Replace part of the base64 ciphertext in the log line
    assert ct_b64 in content
    tampered_content = content.replace(ct_b64[:6], "AAAAAA")
    with open(logger.file_path, "w", encoding="utf-8") as f:
        f.write(tampered_content)

    # Verification must fail
    result = verify_offline_transcript(logger.file_path, receipt_path, cert_path)
    assert result is False
