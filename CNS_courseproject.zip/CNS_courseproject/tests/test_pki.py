"""Unit tests for PKI validation and certificate issuing."""

import datetime
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from app.crypto.pki import (
    BAD_CERT_SIGNATURE,
    CERT_CN_MISMATCH,
    CERT_EXPIRED,
    UNTRUSTED_ISSUER,
    certificate_to_pem,
    load_certificate,
    validate_certificate,
)


@pytest.fixture
def ca_bundle():
    """Create an in-memory Root CA."""
    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "SecureChat Root CA"),
    ])
    now = datetime.datetime.now(datetime.timezone.utc)
    ca_cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(ca_key.public_key())
        .serial_number(1)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(ca_key, hashes.SHA256())
    )
    return ca_key, ca_cert


def test_valid_cert_validation(ca_bundle):
    ca_key, ca_cert = ca_bundle
    entity_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(entity_key.public_key())
        .serial_number(2)
        .not_valid_before(now - datetime.timedelta(minutes=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(ca_key, hashes.SHA256())
    )

    cert_pem = certificate_to_pem(cert)
    ca_pem = certificate_to_pem(ca_cert)

    # Valid with expected CN
    assert validate_certificate(cert_pem, ca_pem, expected_cn="alice") is True
    # Valid without specifying CN
    assert validate_certificate(cert_pem, ca_pem) is True


def test_cert_cn_mismatch(ca_bundle):
    ca_key, ca_cert = ca_bundle
    entity_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(entity_key.public_key())
        .serial_number(3)
        .not_valid_before(now - datetime.timedelta(minutes=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(ca_key, hashes.SHA256())
    )

    cert_pem = certificate_to_pem(cert)
    ca_pem = certificate_to_pem(ca_cert)

    with pytest.raises(CERT_CN_MISMATCH):
        validate_certificate(cert_pem, ca_pem, expected_cn="bob")


def test_cert_expired(ca_bundle):
    ca_key, ca_cert = ca_bundle
    entity_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    # Expired 5 days ago
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(entity_key.public_key())
        .serial_number(4)
        .not_valid_before(now - datetime.timedelta(days=10))
        .not_valid_after(now - datetime.timedelta(days=5))
        .sign(ca_key, hashes.SHA256())
    )

    cert_pem = certificate_to_pem(cert)
    ca_pem = certificate_to_pem(ca_cert)

    with pytest.raises(CERT_EXPIRED):
        validate_certificate(cert_pem, ca_pem, expected_cn="alice")


def test_untrusted_issuer_self_signed(ca_bundle):
    _, ca_cert = ca_bundle
    attacker_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    # Self-signed attacker cert pretending to be Alice
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .public_key(attacker_key.public_key())
        .serial_number(5)
        .not_valid_before(now - datetime.timedelta(minutes=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(attacker_key, hashes.SHA256())
    )

    cert_pem = certificate_to_pem(cert)
    ca_pem = certificate_to_pem(ca_cert)

    with pytest.raises(UNTRUSTED_ISSUER):
        validate_certificate(cert_pem, ca_pem, expected_cn="alice")


def test_bad_cert_signature(ca_bundle):
    ca_key, ca_cert = ca_bundle
    rogue_ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    entity_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    # Claims CA subject as issuer, but signed by rogue key!
    cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(entity_key.public_key())
        .serial_number(6)
        .not_valid_before(now - datetime.timedelta(minutes=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(rogue_ca_key, hashes.SHA256())
    )

    cert_pem = certificate_to_pem(cert)
    ca_pem = certificate_to_pem(ca_cert)

    with pytest.raises(BAD_CERT_SIGNATURE):
        validate_certificate(cert_pem, ca_pem, expected_cn="alice")
