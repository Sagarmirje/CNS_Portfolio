"""
Unit tests for data plane security checks:
Replay attacks, stale timestamp rejection, bit-flip ciphertext tampering,
and signature verification failures.
"""

import os
import shutil
import tempfile
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from app.common.utils import b64_decode, b64_encode, now_ms
from app.crypto.session import SecureChatSession
from app.crypto.sign import compute_message_hash, sign_hash


@pytest.fixture
def session_pair():
    """Create a client and server session with paired keys and certificates."""
    temp_dir = tempfile.mkdtemp()

    # Generate keys
    alice_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    bob_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    # Self-contained certificates
    def make_cert(name, key):
        subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, name)])
        return (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(1)
            .not_valid_before(now_ms() - 100000)
            .not_valid_after(now_ms() + 100000000)
            .sign(key, hashes.SHA256())
        )

    # Use standard datetime for validity
    import datetime
    now = datetime.datetime.now(datetime.timezone.utc)
    alice_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .public_key(alice_key.public_key())
        .serial_number(101)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(alice_key, hashes.SHA256())
    )
    bob_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "bob")]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "bob")]))
        .public_key(bob_key.public_key())
        .serial_number(102)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(bob_key, hashes.SHA256())
    )

    shared_session_key = os.urandom(16)

    alice_session = SecureChatSession(
        session_id="test_sess",
        role="client",
        session_key=shared_session_key,
        local_key=alice_key,
        peer_cert=bob_cert,
        transcripts_dir=temp_dir,
    )

    bob_session = SecureChatSession(
        session_id="test_sess",
        role="server",
        session_key=shared_session_key,
        local_key=bob_key,
        peer_cert=alice_cert,
        transcripts_dir=temp_dir,
    )

    yield alice_session, bob_session

    shutil.rmtree(temp_dir, ignore_errors=True)


def test_valid_message_exchange(session_pair):
    alice_session, bob_session = session_pair
    msg = alice_session.create_message("Hello Bob, this is a top secret message.")

    success, code, pt = bob_session.process_incoming_message(msg)
    assert success is True
    assert code == "OK"
    assert pt == "Hello Bob, this is a top secret message."


def test_replay_attack_rejected(session_pair):
    alice_session, bob_session = session_pair
    msg1 = alice_session.create_message("Transfer $1000")

    # First receive: OK
    ok, code, _ = bob_session.process_incoming_message(msg1)
    assert ok is True
    assert code == "OK"

    # Replay identical message (same seqno): REPLAY
    replay_ok, replay_code, _ = bob_session.process_incoming_message(msg1)
    assert replay_ok is False
    assert replay_code == "REPLAY"

    # Lower seqno also rejected
    msg_low = dict(msg1)
    msg_low["seqno"] = 0
    low_ok, low_code, _ = bob_session.process_incoming_message(msg_low)
    assert low_ok is False
    assert low_code == "REPLAY"


def test_stale_timestamp_rejected(session_pair):
    alice_session, bob_session = session_pair
    msg = alice_session.create_message("Timestamp check")

    # Simulate message from 2 hours ago (7,200,000 ms ago)
    msg["ts"] = msg["ts"] - 7200000
    # Re-sign with correct hash so failure is purely due to timestamp
    digest = compute_message_hash(msg["seqno"], msg["ts"], msg["ct"])
    msg["sig"] = b64_encode(sign_hash(alice_session.local_key, digest))

    ok, code, _ = bob_session.process_incoming_message(msg)
    assert ok is False
    assert code == "STALE"


def test_ciphertext_tampering_rejected_sig_fail(session_pair):
    alice_session, bob_session = session_pair
    msg = alice_session.create_message("Payment of 100 USD")

    # Attacker flips a byte in ciphertext to change payload
    ct_bytes = bytearray(b64_decode(msg["ct"]))
    ct_bytes[-1] ^= 0x01
    msg["ct"] = b64_encode(bytes(ct_bytes))

    ok, code, _ = bob_session.process_incoming_message(msg)
    assert ok is False
    assert code == "SIG_FAIL"


def test_seqno_tampering_rejected_sig_fail(session_pair):
    alice_session, bob_session = session_pair
    msg = alice_session.create_message("Tampering test")

    # Attacker modifies seqno in transit
    msg["seqno"] = 999

    ok, code, _ = bob_session.process_incoming_message(msg)
    assert ok is False
    assert code == "SIG_FAIL"
