"""Unit tests for cryptographic primitives (DH, AES-128-CBC, RSA SHA-256)."""

import os
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from app.crypto.aes import AESDecryptionError, decrypt_aes_cbc, encrypt_aes_cbc
from app.crypto.dh import (
    DHAuthError,
    DHValidationError,
    DiffieHellman,
    sign_dh_exchange,
    verify_dh_exchange,
)
from app.crypto.sign import (
    SignatureVerificationError,
    compute_message_hash,
    sign_data,
    sign_hash,
    verify_data,
    verify_hash,
)


def test_dh_shared_key_derivation():
    """Verify both parties compute identical 16-byte AES keys."""
    alice_dh = DiffieHellman()
    bob_dh = DiffieHellman()

    alice_key = alice_dh.derive_key(bob_dh.public_key)
    bob_key = bob_dh.derive_key(alice_dh.public_key)

    assert len(alice_key) == 16
    assert len(bob_key) == 16
    assert alice_key == bob_key


def test_dh_public_validation():
    """Verify out-of-range DH public values are rejected."""
    dh = DiffieHellman()

    with pytest.raises(DHValidationError):
        dh.validate_peer_public(0)

    with pytest.raises(DHValidationError):
        dh.validate_peer_public(1)

    with pytest.raises(DHValidationError):
        dh.validate_peer_public(dh.p - 1)

    with pytest.raises(DHValidationError):
        dh.validate_peer_public(dh.p + 5)


def test_authenticated_dh_signing():
    """Verify signature over DH public value and nonce."""
    alice_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    alice_dh = DiffieHellman()
    nonce = os.urandom(16)

    sig = sign_dh_exchange(alice_key, alice_dh.public_key, nonce)
    # Valid verification
    assert verify_dh_exchange(alice_key.public_key(), alice_dh.public_key, nonce, sig) is True

    # Tampered nonce fails
    with pytest.raises(DHAuthError):
        verify_dh_exchange(alice_key.public_key(), alice_dh.public_key, os.urandom(16), sig)


def test_aes_cbc_encrypt_decrypt_roundtrip():
    """Verify AES-128-CBC encryption and decryption with various payload lengths."""
    key = os.urandom(16)
    messages = [
        b"",
        b"A",
        b"Hello SecureChat!",
        b"16-byte block!!!",
        b"Multi-block message exceeding 16 bytes for testing PKCS#7 padding safely.",
    ]

    for msg in messages:
        encrypted = encrypt_aes_cbc(key, msg)
        assert len(encrypted) >= 32  # 16-byte IV + at least 16-byte block
        decrypted = decrypt_aes_cbc(key, encrypted)
        assert decrypted == msg


def test_aes_cbc_bad_padding_or_tampering():
    """Verify corrupted ciphertext raises AESDecryptionError."""
    key = os.urandom(16)
    msg = b"Confidential banking transaction payload"
    encrypted = bytearray(encrypt_aes_cbc(key, msg))

    # Flip one bit in the last block (affecting padding)
    encrypted[-1] ^= 0x01

    with pytest.raises(AESDecryptionError):
        decrypt_aes_cbc(key, bytes(encrypted))


def test_rsa_message_hashing_and_signing():
    """Verify SHA-256 and RSA signing of message payloads."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    seqno = 42
    ts = 1700000000000
    ct_b64 = "U2VjdXJlQ2hhdFRlc3RDaXBoZXJ0ZXh0"

    digest = compute_message_hash(seqno, ts, ct_b64)
    sig = sign_hash(key, digest)

    # Valid verification
    assert verify_hash(key.public_key(), digest, sig) is True

    # Tampered sequence number fails verification
    tampered_digest = compute_message_hash(seqno + 1, ts, ct_b64)
    with pytest.raises(SignatureVerificationError):
        verify_hash(key.public_key(), tampered_digest, sig)
