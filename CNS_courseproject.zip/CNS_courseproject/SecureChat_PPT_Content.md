# SecureChat Project Presentation — Detailed Content

## Slide 1: Title

**SecureChat: Secure Multi-Client Chat Using Hybrid Cryptography**

- Cryptography and Network Security Course Project
- Secure communication for the Alice and Bob chat identities
- Technologies: Python, TCP sockets, X.509 certificates, Diffie–Hellman, AES-128-CBC, RSA, SHA-256, Flask
- Presenter:
- Guide:
- Year: 2026

**Visual suggestion:** Light or dark shield icon beside a secure chat message box. Use the project dashboard screenshot in the bottom corner.

**Speaker opening:** “Today I will demonstrate a complete secure chat system that not only encrypts messages, but also authenticates identities, detects tampering and replay, and creates cryptographic evidence for every session.”

---

## Slide 2: Table of Contents

1. Abstract
2. Introduction
3. Problem Statement
4. Objectives
5. Concepts Used
6. Solution Overview
7. Implementation and Flow Diagram
8. Technologies Used
9. Security Threat Model
10. Demonstration
11. Testing and Results
12. Conclusion
13. References

**Speaker note:** Briefly state that the presentation moves from the problem to the architecture, implementation, live demonstration, and final security evaluation.

---

## Slide 3: Abstract

**Abstract:**

SecureChat is a secure, multithreaded client-server chat application designed to demonstrate how different cryptographic mechanisms work together in a real communication system. It combines mutual X.509 certificate authentication, Diffie–Hellman key agreement, AES-128-CBC message encryption, RSA digital signatures, SHA-256 hashing, replay protection, timestamp validation, append-only transcripts, and signed SessionReceipts.

**Key points:**

- Communication occurs over a TCP socket connection on port 8443.
- The web dashboard runs as a Flask application on port 5000.
- Password credentials are protected using an ephemeral Diffie–Hellman-derived AES key.
- Chat messages are encrypted for confidentiality and signed for integrity and origin authentication.
- Sequence numbers prevent replay attacks.
- Cryptographic transcripts and receipts provide non-repudiation.

**Visual suggestion:** Add a horizontal pipeline: Certificate → Temporary Key → Session Key → Encrypted Message → Signed Transcript.

---

## Slide 4: Introduction

### Context

Secure chat applications must protect more than ordinary text. They must protect identities, credentials, message content, network state, and the history of the conversation.

### What SecureChat demonstrates

- How TLS-like security concepts can be implemented using separate cryptographic primitives.
- How a private Certificate Authority can authenticate both server and client identities.
- How session keys protect messages in a short-lived chat room.
- How a receiver detects altered, repeated, or stale packets.
- How signed receipts create evidence that a participant sent or received a conversation record.

### Users

- **Alice:** Client with a certificate issued by the project Root CA.
- **Bob:** Second client with its own certificate issued by the same Root CA.
- **Server:** Authenticates clients and relays encrypted chat packets.
- **Database:** Stores users and salted password hashes.

**Speaker note:** Explain that this project is a controlled educational implementation, not a replacement for professionally audited software such as Signal or TLS.

---

## Slide 5: Problem Statement

A normal chat application may contain the following weaknesses:

1. **Credentials exposed on the network:** Passwords could be captured by packet sniffing.
2. **Message confidentiality not guaranteed:** An attacker could read chat content.
3. **Identity spoofing:** A malicious party could pretend to be a real user or server.
4. **Undetected tampering:** Ciphertext or metadata could be modified during transmission.
5. **Replay attacks:** A previously valid encrypted packet could be copied and sent again.
6. **Stale packets:** Delayed messages could be injected with reused or old timestamps.
7. **Denial of origin:** A participant could later claim that a message was never sent.

**Project problem statement:**

> To design and implement a multiclient chat system that provides confidentiality, integrity, mutual authentication, forward secrecy, replay protection, and non-repudiation using a hybrid combination of symmetric cryptography, public-key cryptography, certificates, secure key agreement, and cryptographic audit records.

---

## Slide 6: Objectives

1. **Confidentiality:** Encrypt passwords and chat messages.
2. **Mutual authentication:** Authenticate the server and both clients using X.509 certificates.
3. **Integrity:** Detect any modification of sequence number, timestamp, or ciphertext.
4. **Forward secrecy:** Derive fresh session keys for individual chat sessions.
5. **Replay protection:** Accept only a sequence number higher than the last accepted number.
6. **Freshness:** Reject timestamps outside the ±60-second acceptance window.
7. **Non-repudiation:** Generate signed SessionReceipts and append-only transcript evidence.
8. **Usability:** Provide both a command-line interface and a Flask web dashboard.
9. **Attack demonstration:** Display visible rejection of tampered, replayed, and stale packets.
10. **Verification:** Provide unit tests and an offline transcript verifier.

---

## Slide 7: Concepts Used

### Public-Key Infrastructure

- A project-specific Root CA signs the server and client certificates.
- Certificate validation checks issuer, validity dates, common name, and key usage.

### Diffie–Hellman Key Agreement

- The temporary exchange protects authentication credentials.
- A second authenticated exchange creates a fresh per-session AES key.
- Neither derived secret is directly transmitted on the network.

### AES-128-CBC

- AES encrypts credentials and chat payloads.
- CBC mode requires a random 16-byte IV.
- PKCS#7 padding allows variable-length messages.
- The IV is prepended to the ciphertext.

### RSA and SHA-256

- RSA signs cryptographic data with the sender’s private key.
- SHA-256 creates message hashes and transcript hashes.
- The receiver verifies the RSA signature using the sender’s public key.

### Replay and Freshness Controls

- The sequence number must increase for every accepted message.
- The timestamp must remain within 60 seconds of the server clock.

### Non-Repudiation

- An append-only transcript records signed messages.
- An RSA-signed SessionReceipt summarizes the transcript.
- The offline verifier recalculates and compares cryptographic evidence.

---

## Slide 8: Solution Overview

### 8-Step Protocol

**Steps 1–2: Mutual PKI Authentication**

- The client opens a TCP connection to the server.
- The client and server exchange certificates.
- Both sides validate the peer certificate against the Root CA.

**Step 3: Temporary Diffie–Hellman and Credential Encryption**

- Both sides exchange ephemeral Diffie–Hellman public values.
- They derive a temporary 16-byte AES key.
- Registration or login occurs in AES-CBC encrypted JSON.

**Steps 4–5: Authenticated Session Key Agreement**

- Server and client generate fresh session DH values.
- Values and nonce information are RSA-signed.
- The server and client derive the session AES key independently.

**Steps 6–7: Secure Chat Data Plane**

- Each outgoing message is padded and AES-encrypted.
- A SHA-256 hash covers sequence number, timestamp, and ciphertext.
- RSA signs the hash.
- The receiver verifies replay state, freshness, signature, and decryption.

**Step 8: SessionReceipt Exchange**

- The client and server calculate transcript summaries.
- Each side generates a RSA-signed receipt.
- Receipts are saved for offline audit and third-party verification.

**Visual suggestion:** Use the project architecture diagram and highlight one step at a time.

---

## Slide 9: System Architecture

### Components

**Web Interface:**

- Flask server on port 5000
- Certificate information
- Login and registration controls
- Chat interface
- Crypto envelope inspector
- Attack simulator
- Evidence and transcript audit panel

**TCP Application Server:**

- Runs on port 8443
- Accepts concurrent client connections
- Handles each client in a separate thread
- Registers active users
- Broadcasts chat messages to verified peers
- Generates final SessionReceipts

**Cryptographic Modules:**

- `pki.py`: certificates and validation
- `dh.py`: Diffie–Hellman and key derivation
- `aes.py`: AES-128-CBC and PKCS#7
- `sign.py`: SHA-256 and RSA signing
- `session.py`: receiver verification engine

**Storage:**

- `db.py`: MySQL support with SQLite fallback
- `transcript.py`: transcript and receipt generation
- `securechat.db`: local SQLite database
- `transcripts/`: session evidence files

**Visual suggestion:** Use three columns: Web/CLI Client → TCP Server → Database and Evidence Storage.

---

## Slide 10: Implementation Flow Diagram

### Packet flow

```text
Alice / Bob
    |
    | 1. TCP connection
    v
SecureChat Server
    |
    | 2. Exchange certificates
    v
Mutual X.509 Validation
    |
    | 3. Ephemeral DH exchange
    v
Temporary AES-128 Key
    |
    | 4. Encrypted login/register
    v
Database Verification
    |
    | 5. Signed session DH exchange
    v
Fresh Session AES-128 Key
    |
    | 6. Signed and encrypted message
    v
Receiver Validation
    |-- Replay check
    |-- Timestamp freshness check
    |-- RSA signature check
    `-- AES decryption check
    |
    | 7. Append transcript
    v
Broadcast to peers
    |
    | 8. Exchange signed receipts
    v
Offline Verification Evidence
```

### Sender packet fields

- `type`: Message type
- `seqno`: Increasing sequence number
- `ts`: Timestamp in milliseconds
- `ct`: Base64-encoded AES ciphertext
- `sig`: Base64-encoded RSA signature

### Receiver order

1. Replay check
2. Freshness check
3. Signature check
4. AES decryption

**Visual suggestion:** Use numbered arrows and a separate validation box on the right.

---

## Slide 11: Technologies Used

| Area | Technology | Purpose |
|---|---|---|
| Language | Python | Core implementation |
| Client-server network | TCP sockets | Reliable bidirectional communication |
| Web interface | Flask | HTTP dashboard and API |
| Database | SQLite / MySQL | User credentials and metadata |
| Certificates | X.509 | Mutual identity authentication |
| Key exchange | Diffie–Hellman | Temporary and session keys |
| Symmetric encryption | AES-128-CBC | Confidentiality |
| Hashing | SHA-256 | Message and transcript integrity |
| Digital signature | RSA | Origin authentication and non-repudiation |
| Data format | JSON | Structured protocol messages |
| Framing | 4-byte length prefix | Safe TCP message boundaries |
| Testing | pytest | Automated unit tests |

**Visual suggestion:** Use a technology stack diagram instead of a dense table.

---

## Slide 12: Security Threat Model

| Threat | Attacker Action | Defense |
|---|---|---|
| Eavesdropping | Capture and read network traffic | AES-128-CBC encryption |
| Credential theft | Intercept login data | Ephemeral DH encryption and password hashing |
| Impersonation | Pretend to be Alice, Bob or the server | Mutual certificate validation |
| MITM attack | Substitute DH public values | RSA-sign the authenticated DH exchange |
| Tampering | Modify sequence number, timestamp or ciphertext | SHA-256 hash and RSA signature |
| Replay | Re-send an earlier valid packet | Monotonically increasing sequence numbers |
| Stale packet injection | Send an old delayed packet | ±60-second timestamp check |
| Denial of origin | Deny sending a message | Signed transcript and SessionReceipt |
| Oversized packet | Attempt memory exhaustion | 64 KB maximum frame size |

**Key message:** No single cryptographic primitive protects the complete system. The project combines primitives to defend against independent threats.

---

## Slide 13: Live Demonstration Steps

### Demonstration 1: Certificate and Session Setup

1. Open `http://127.0.0.1:5000`.
2. Select Alice.
3. Click **Run Step 1 & 2: PKI Handshake**.
4. Point to the server status and certificate thumbprint.
5. Log in with the Alice account.

### Demonstration 2: Chat

1. Open another browser window and select Bob.
2. Connect and log in as Bob.
3. Send a message from Alice.
4. Observe Bob receive the message.
5. Click **Inspect Crypto Envelope**.
6. Explain sequence number, timestamp, ciphertext, and signature.

### Demonstration 3: Attack Defense

1. Click **Tamper Ciphertext**.
2. Point out the `SIG_FAIL` rejection.
3. Click **Replay Previous Msg**.
4. Point out the `REPLAY` rejection.
5. Click **Inject Stale Msg (-5m)**.
6. Point out the `STALE` rejection.

### Demonstration 4: Evidence

1. Click **Run Cryptographic Audit**.
2. Explain transcript hash comparison.
3. Point out the valid RSA-signed SessionReceipt.
4. Click **Terminate Session & Sign Receipt**.

**Credentials:**

- Alice: `alice@securechat.io` / `Password123!`
- Bob: `bob@securechat.io` / `Password456!`

---

## Slide 14: Implementation Files

| File / Folder | Responsibility |
|---|---|
| `app/client.py` | Client connection, credential exchange, session DH and chat |
| `app/server.py` | Multithreaded server and active-session management |
| `app/web_ui.py` | Flask dashboard and demonstration APIs |
| `app/common/protocol.py` | TCP length-prefix framing |
| `app/common/utils.py` | Encoding, timestamps and constant-time comparison |
| `app/crypto/pki.py` | Certificate loading and validation |
| `app/crypto/dh.py` | Diffie–Hellman calculations |
| `app/crypto/aes.py` | AES-128-CBC encryption and decryption |
| `app/crypto/sign.py` | Hashing and RSA signatures |
| `app/crypto/session.py` | Replay, freshness and receiver validation |
| `app/storage/db.py` | Database operations and SQLite fallback |
| `app/storage/transcript.py` | Transcript generation and receipts |
| `tools/verify_transcript.py` | Offline transcript verification |
| `scripts/demo_attacks.py` | Automated security scenario demonstrations |
| `tests/` | Cryptographic and replay/tamper tests |

**Visual suggestion:** Show a source-code folder diagram rather than a text table.

---

## Slide 15: Testing and Results

### Automated Tests

- 18 pytest tests passed.
- Cryptographic module compilation passed.
- The project imported required dependencies successfully.

### Test Areas

- Diffie–Hellman shared-key derivation.
- AES encryption/decryption round trips.
- AES tampering and invalid padding rejection.
- RSA signature creation and verification.
- Replay message rejection.
- Stale timestamp rejection.
- Certificate validation.
- Transcript hash verification.

### Demonstrated Runtime Results

- Alice and Bob successfully authenticated.
- Fresh session AES keys were established.
- Valid messages were accepted and delivered.
- Tampered ciphertext was rejected with `SIG_FAIL`.
- Replayed packets were rejected with `REPLAY`.
- Old timestamps were rejected with `STALE`.
- Session receipts were RSA-signed and saved.

**Visual suggestion:** Use green pass badges and a dashboard screenshot.

---

## Slide 16: Results and Screenshots

### Screen 1: Command Center

Show:

- Server status
- Mutual authentication status
- Active AES session status
- Selected identity
- Certificate thumbprint

### Screen 2: Chat Room

Show:

- Alice or Bob messages
- Session ID
- E2EE status
- Packet inspector button

### Screen 3: Attack Defense Sandbox

Show:

- Tamper ciphertext
- Replay previous message
- Inject stale message

### Screen 4: Evidence Panel

Show:

- Append-only cryptographic logs
- Transcript hash
- RSA receipt validation
- Audit result

**Speaker note:** Explain what is real and what is simulated. Real cryptographic attack controls are sent through the web demonstration, while the packet values remain visible for teaching purposes.

---

## Slide 17: Limitations

1. The project is intended for education and local demonstration.
2. The Flask development server should not be used directly in production.
3. Certificate rotation and revocation are not fully automated.
4. Private keys are stored as local files and need stronger secret protection in a production environment.
5. The application uses a simple TCP protocol rather than a complete TLS implementation.
6. SQLite is used as a fallback and is suitable for local demonstration.
7. The system does not include all protections found in a fully audited messaging system.

**Best practice note:** Future versions could use TLS 1.3, hardware-backed keys, secure key storage, certificate revocation checks, and a formal cryptographic protocol review.

---

## Slide 18: Future Improvements

- Replace local Flask development with Gunicorn or another production server.
- Add mutual TLS for the underlying transport.
- Use a full message API and database migration system.
- Implement Certificate Revocation Lists or OCSP.
- Add secure logout and key erasure.
- Add account lockout and rate limiting.
- Rotate and expire session keys automatically.
- Encrypt database backups.
- Use audited cryptographic libraries and protocol implementations.
- Add a mobile or responsive frontend.
- Improve concurrent request locking for the web dashboard.
- Add Docker deployment and automated setup scripts.

---

## Slide 19: Conclusion

SecureChat successfully demonstrates the layered use of modern cryptographic concepts in a working chat application.

### Main achievements

- Mutual certificate authentication prevents impersonation.
- Ephemeral Diffie–Hellman protects credentials and creates session keys.
- AES-128-CBC protects message confidentiality.
- RSA signatures provide integrity and origin authentication.
- Sequence numbers stop replay attacks.
- Timestamp validation rejects stale packets.
- Append-only transcripts and signed receipts provide non-repudiation.

### Final conclusion

The project shows that security is not achieved by one algorithm alone. It requires many coordinated defenses operating across authentication, key exchange, data protection, replay prevention, and audit evidence.

---

## Slide 20: References

1. Project repository: `README.md` and SecureChat source code.
2. Python Cryptography Library Documentation: https://cryptography.io/
3. Flask Documentation: https://flask.palletsprojects.com/
4. RFC 3526: More Modular Exponential (MODP) Diffie–Hellman Groups for Internet Key Exchange (IKE).
5. RFC 5246 / RFC 8446: TLS protocol design references.
6. NIST, *Recommendation for Key Management*.
7. NIST FIPS 180-4: Secure Hash Standard.
8. NIST FIPS 197: Advanced Encryption Standard.
9. OWASP Authentication and Cryptographic Storage guidance.
10. OpenSSL / X.509 certificate standards documentation.

**Optional references to add:**

- Your course textbook
- Your faculty or lab guide
- Any official project template or submission format

---

# Presenter Closing Script

“SecureChat was implemented as an eight-step security protocol. We began with mutual certificate authentication, then used ephemeral and authenticated Diffie–Hellman exchanges to derive encryption keys. Credentials and chat messages are protected with AES-128-CBC, while SHA-256 and RSA signatures detect tampering and verify origin. The receiver rejects replayed and stale messages, and the final transcript and SessionReceipt provide non-repudiation evidence. The live dashboard lets us demonstrate each defense in real time.”

# Suggested Q&A Answers

### Why AES-128-CBC?

AES-128-CBC provides a recognized 128-bit symmetric encryption standard. The project uses a random IV for each encryption and PKCS#7 padding for variable-length content.

### Why two Diffie–Hellman exchanges?

The first exchange protects registration and login credentials. The second exchange creates a fresh, signed session key for chat messages.

### Why are RSA signatures used if AES already encrypts messages?

Encryption provides confidentiality, but it does not prove who sent a message or detect every in-transit modification. RSA signatures prove origin and integrity.

### What prevents replay attacks?

Every sender packet has an increasing sequence number. The receiver rejects a packet whose sequence number is not greater than the last accepted sequence number.

### What prevents stale messages?

The timestamp is compared with the receiver’s current time. Messages outside a ±60-second window are rejected.

### What is forward secrecy?

A fresh session DH key is generated for a chat session, so compromise of an old session key should not reveal future session keys.

### What is non-repudiation?

The sender’s and server’s RSA-signed receipts and transcript evidence make it difficult for participants to deny participation in the recorded session.

### What happens if MySQL is unavailable?

The database module falls back to a local SQLite database named `securechat.db`.

### What are the main limitations?

The project is a local educational implementation and should not be treated as a production cryptographic messenger. Production deployment would require stronger key storage, TLS, certificate lifecycle management, rate limiting, audited protocol implementation, and secure server deployment.
