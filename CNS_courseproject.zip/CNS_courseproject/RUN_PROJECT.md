# SecureChat - Commands to Run the Project

Run all commands from the project folder:

```powershell
cd d:\CNS_courseproject
```

## 1. Activate the virtual environment

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
```

## 2. Install dependencies

```powershell
python -m pip install -r requirements.txt
```

## 3. Initialize certificates

Generate the Root CA:

```powershell
python scripts\gen_ca.py
```

Generate the server certificate:

```powershell
python scripts\gen_cert.py server server
```

Generate the Alice certificate:

```powershell
python scripts\gen_cert.py alice client
```

Generate the Bob certificate:

```powershell
python scripts\gen_cert.py bob client
```

## 4. Initialize the database

```powershell
python scripts\init_db.py
```

MySQL is optional. If MySQL is unavailable or not running, the project automatically falls back to the local SQLite database `securechat.db`.

## 5. Start the SecureChat server

Open **Terminal 1** and run:

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python app\server.py --host 127.0.0.1 --port 8443
```

Keep this terminal open. The server listens on:

```text
127.0.0.1:8443
```

## 6. Start the web interface

Open **Terminal 2** and run:

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python app\web_ui.py
```

Keep this terminal open. Open the dashboard in a browser:

```text
http://127.0.0.1:5000
```

## 7. Optional command-line clients

Open separate terminals for each client.

### Alice

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python app\client.py --user alice --host 127.0.0.1 --port 8443
```

### Bob

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python app\client.py --user bob --host 127.0.0.1 --port 8443
```

## 8. Run automated tests

Open a new terminal:

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python -m pytest -q
```

## 9. Run the attack demonstration

Keep the backend server and web interface running, then open another terminal:

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python scripts\demo_attacks.py
```

## 10. Run the end-to-end demonstration

```powershell
cd d:\CNS_courseproject
.\.venv\Scripts\Activate.ps1
python scripts\demo_chat_e2e.py
```

## 11. Verify a transcript offline

List generated transcript and receipt files:

```powershell
Get-ChildItem transcripts
```

Run the verifier using the required log, receipt, and peer certificate files:

```powershell
python tools\verify_transcript.py transcripts\<session-id>_server.log transcripts\<session-id>_server_peer_receipt.json certs\alice.crt
```

Replace `<session-id>` with the actual session filename identifier.

## 12. Stop the running services

In the server and web-interface terminals, press:

```text
Ctrl+C
```

## Typical demonstration sequence

1. Start the TCP server.
2. Start the web interface.
3. Open `http://127.0.0.1:5000`.
4. Select Alice or Bob.
5. Register if required, then log in.
6. Open a second browser window and connect as the other user.
7. Exchange messages.
8. Run the tamper, replay, and stale-message attack controls.
9. Run the cryptographic audit.
10. Terminate the session and sign the receipt.
