from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor

OUT = r"d:\CNS_courseproject\SecureChat_Project_Presentation.pptx"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

NAVY = RGBColor(8, 18, 38)
BLUE = RGBColor(33, 105, 196)
CYAN = RGBColor(32, 201, 218)
WHITE = RGBColor(246, 249, 255)
LIGHT = RGBColor(205, 216, 238)
GRAY = RGBColor(145, 158, 185)
GREEN = RGBColor(61, 220, 151)
RED = RGBColor(245, 97, 97)


def add_bg(slide):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = NAVY


def title(slide, text, number=None):
    box = slide.shapes.add_textbox(Inches(0.7), Inches(0.45), Inches(11.8), Inches(0.7))
    p = box.text_frame.paragraphs[0]
    p.text = text
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = WHITE
    if number:
        n = slide.shapes.add_textbox(Inches(12.2), Inches(0.48), Inches(0.5), Inches(0.5))
        q = n.text_frame.paragraphs[0]
        q.text = number
        q.font.size = Pt(13)
        q.font.bold = True
        q.font.color.rgb = CYAN
        q.alignment = PP_ALIGN.RIGHT


def add_text(slide, text, x, y, w, h, size=18, color=LIGHT, bold=False):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.color.rgb = color
    p.font.bold = bold
    return box


def bullets(slide, items, x=0.9, y=1.45, w=11.5, h=5.2, size=20):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = item
        p.level = 0
        p.font.size = Pt(size)
        p.font.color.rgb = LIGHT
        p.space_after = Pt(12)
        p.text = "• " + p.text


def card(slide, x, y, w, h, heading, body, accent=BLUE):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb = RGBColor(18, 38, 72)
    shape.line.color.rgb = accent
    shape.line.width = Pt(1.5)
    add_text(slide, heading, x+0.25, y+0.18, w-0.5, 0.45, 18, accent, True)
    add_text(slide, body, x+0.25, y+0.72, w-0.5, h-0.9, 14, LIGHT)


def arrow(slide, x1, y1, x2, y2):
    line = slide.shapes.add_connector(1, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    line.line.color.rgb = CYAN
    line.line.width = Pt(2)

# 1 Title
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide)
shield = slide.shapes.add_shape(MSO_SHAPE.HEXAGON, Inches(0.9), Inches(1.5), Inches(1.55), Inches(1.55))
shield.fill.solid(); shield.fill.fore_color.rgb = BLUE; shield.line.color.rgb = CYAN
add_text(slide, "S", 1.36, 1.88, 0.7, 0.7, 42, WHITE, True)
add_text(slide, "SecureChat", 2.75, 1.35, 8.8, 0.7, 34, WHITE, True)
add_text(slide, "Secure Multi-Client Chat System", 2.78, 2.05, 8.8, 0.55, 24, CYAN)
add_text(slide, "Hybrid Cryptography • Mutual Authentication • Replay Protection • Non-Repudiation", 2.78, 2.75, 9.3, 0.5, 16, LIGHT)
add_text(slide, "Cryptography and Network Security Course Project", 2.78, 5.55, 8.8, 0.35, 16, GRAY)
add_text(slide, "2026", 11.7, 6.55, 0.8, 0.35, 14, CYAN, True)

# 2 Table of contents
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Table of Contents", "02")
sections = [("01", "Abstract"), ("02", "Introduction"), ("03", "Problem Statement"), ("04", "Objectives"), ("05", "Concepts Used"), ("06", "Solution Overview"), ("07", "Implementation"), ("08", "Conclusion"), ("09", "References")]
for i, (n, s) in enumerate(sections):
    col = i % 3; row = i // 3
    x = 0.9 + col*4.05; y = 1.5 + row*1.35
    card(slide, x, y, 3.55, 1.05, n, s, CYAN if i < 4 else BLUE)

# 3 Abstract
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Abstract", "03")
add_text(slide, "SecureChat combines multiple cryptographic techniques to protect every stage of a conversation.", 0.9, 1.4, 11.5, 0.7, 22, WHITE, True)
bullets(slide, ["Provides confidentiality, integrity, authentication and replay protection", "Uses an encrypted TCP protocol with a Flask web interface", "Authenticates users and devices with a private Root CA", "Records signed transcripts and SessionReceipts for offline verification", "Falls back to SQLite when MySQL is unavailable"], size=19)

# 4 Introduction
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Introduction", "04")
card(slide, 0.9, 1.5, 3.55, 3.7, "The Need", "Traditional chat systems may expose credentials or messages. A secure system must verify identities and protect data in transit.", BLUE)
card(slide, 4.75, 1.5, 3.55, 3.7, "The Goal", "Create a practical client-server chat platform demonstrating modern cryptography in a real network flow.", CYAN)
card(slide, 8.6, 1.5, 3.55, 3.7, "The Result", "Alice and Bob can connect, authenticate, exchange encrypted messages, and verify signed evidence.", GREEN)

# 5 Problem statement
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Problem Statement", "05")
bullets(slide, ["Plaintext communication can be read by attackers", "Certificates and identities are needed to prevent impersonation", "Message alteration must be detectable", "Captured valid packets must not be accepted twice", "Receipts are needed to prevent denial of a sent message"], size=22)

# 6 Objectives
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Objectives", "06")
objectives = [("1", "Confidentiality", "Encrypt credentials and chat data"), ("2", "Integrity", "Detect changes using hashes and signatures"), ("3", "Authentication", "Validate server and client certificates"), ("4", "Replay Defense", "Reject repeated sequence numbers"), ("5", "Freshness", "Reject stale timestamps"), ("6", "Non-Repudiation", "Sign transcripts and SessionReceipts")]
for i,(n,h,b) in enumerate(objectives):
    col=i%3; row=i//3
    card(slide, 0.9+col*4.05, 1.45+row*2.25, 3.55, 1.75, h, b, CYAN if i%2==0 else BLUE)

# 7 Concepts used
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Concepts Used", "07")
concepts = [("PKI / X.509", "Issue and validate certificates"), ("Diffie–Hellman", "Create shared secrets securely"), ("AES-128-CBC", "Encrypt payloads with random IVs"), ("RSA + SHA-256", "Create and verify digital signatures"), ("Salted Hashing", "Protect stored passwords"), ("Append-only Logs", "Preserve verifiable conversation evidence")]
for i,(h,b) in enumerate(concepts):
    col=i%3; row=i//3
    card(slide, 0.9+col*4.05, 1.45+row*2.25, 3.55, 1.75, h, b, [BLUE,CYAN,GREEN][i%3])

# 8 Solution overview
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Solution Overview", "08")
steps = ["TCP Connection", "Mutual PKI", "Temporary DH", "Encrypted Login", "Session DH", "AES Messages", "Signed Transcript", "SessionReceipt"]
for i, step in enumerate(steps):
    x=0.45+i*1.58
    shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(2.45), Inches(1.28), Inches(1.18))
    shape.fill.solid(); shape.fill.fore_color.rgb=RGBColor(18,38,72); shape.line.color.rgb=CYAN
    add_text(slide, str(i+1), x+0.43, 2.62, 0.42, 0.35, 18, CYAN, True)
    add_text(slide, step, x+0.08, 3.03, 1.12, 0.55, 11, LIGHT, True)
    if i<7: arrow(slide,x+1.28,3.04,x+1.58,3.04)
add_text(slide, "Eight-step secure protocol", 4.8, 1.45, 4.2, 0.5, 22, WHITE, True)

# 9 Implementation flow
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Implementation — 8-Step Flow", "09")
boxes = [(0.7,1.45,"1–2","TCP + Mutual PKI"),(3.55,1.45,"3","Temporary DH + Login"),(6.4,1.45,"4–5","Signed Session DH"),(9.25,1.45,"6–7","Encrypted + Signed Chat"),(5.0,4.15,"8","Transcript + Receipt")]
for i,(x,y,n,b) in enumerate(boxes):
    shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(2.45), Inches(1.25))
    shape.fill.solid(); shape.fill.fore_color.rgb=RGBColor(18,38,72); shape.line.color.rgb=CYAN
    add_text(slide,n,x+0.15,y+0.15,0.55,0.4,18,CYAN,True)
    add_text(slide,b,x+0.15,y+0.62,2.15,0.45,14,LIGHT,True)
arrow(slide,3.15,2.08,3.55,2.08); arrow(slide,6.0,2.08,6.4,2.08); arrow(slide,8.85,2.08,9.25,2.08)
arrow(slide,10.47,2.7,6.23,4.15)
add_text(slide,"Receiver checks: replay → freshness → RSA signature → AES decryption", 1.15, 3.15, 11.0, 0.55, 18, GREEN, True)

# 10 Implementation components
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Implementation Components", "10")
components=[("Frontend","Flask web dashboard and packet inspector"),("TCP Server","Multithreaded client handlers"),("Cryptography","PKI, DH, AES, RSA and SHA-256"),("Storage","SQLite fallback and append-only transcripts"),("Testing","18 automated pytest cases"),("Audit Tools","Offline transcript and receipt verification")]
for i,(h,b) in enumerate(components):
    col=i%2; row=i//2
    card(slide, 0.9+col*6.05, 1.45+row*1.7, 5.55, 1.35, h, b, CYAN if i%2==0 else BLUE)

# 11 Live demonstration
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Live Demonstration", "11")
bullets(slide,["Connect Alice and Bob through the web interface","Demonstrate certificate handshake and session key derivation","Send encrypted messages and inspect the crypto envelope","Simulate tampering → expect SIG_FAIL","Replay an old message → expect REPLAY","Submit a stale timestamp → expect STALE","Run transcript audit and terminate with a signed receipt"],size=20)

# 12 Conclusion
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "Conclusion", "12")
card(slide,0.9,1.5,3.55,3.8,"Delivered","A complete secure chat system with authentication, encryption, signatures and audit evidence.",CYAN)
card(slide,4.75,1.5,3.55,3.8,"Demonstrated","The system visibly rejects tampered, replayed and stale messages.",GREEN)
card(slide,8.6,1.5,3.55,3.8,"Verified","Automated tests confirm the cryptographic primitives and transcript behavior.",BLUE)

# 13 References
slide = prs.slides.add_slide(prs.slide_layouts[6]); add_bg(slide); title(slide, "References", "13")
bullets(slide,["Project README and source code: README.md","Python Cryptography documentation","Flask web framework documentation","RFC 3526 — More Modular Exponential (MODP) Diffie–Hellman Groups","NIST guidance on cryptographic hash functions and digital signatures"],size=19)

# Footer on content slides
for idx, slide in enumerate(prs.slides):
    if idx == 0:
        continue
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(7.25), prs.slide_width, Inches(0.25))
    line.fill.solid(); line.fill.fore_color.rgb = BLUE; line.line.fill.background()

prs.save(OUT)
print(OUT)
