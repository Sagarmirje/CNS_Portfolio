# SecureChat: Secure Chat System Using Hybrid Cryptography

**SecureChat** is an end-to-end secure, multithreaded client-server chat system designed for Cryptography & Network Security (CNS). It integrates hybrid cryptography primitives to provide **Confidentiality, Integrity, Mutual Authentication, Forward Secrecy, Replay Protection, and Non-Repudiation**.

---

## 1. System Architecture & 8-Step Protocol Flow

```mermaid
sequenceDiagram
    autonumber
    participant C as Client (Alice)
    participant S as Server (Bob)
    participant DB as MySQL Database

    Note over C,S: Step 1 & 2: TCP Connection & Mutual PKI Authentication
    C->>S: TCP Connect to 8443
    C->>S: Handshake {type: "handshake", cert: client_cert_pem}
    S->>C: Handshake {type: "handshake", cert: server_cert_pem}
    Note over C,S: Both validate peer cert against Root CA (Signature, Dates, CN, KeyUsage)

    Note over C,S: Step 3: Ephemeral DH & Encrypted Credentials (Zero Plaintext on Wire)
    C->>S: DH Init {type: "dh_init", dh_pub: Y_c}
    S->>C: DH Init {type: "dh_init", dh_pub: Y_s}
    Note over C,S: Both derive K_temp = Trunc16(SHA-256(shared_secret))
    C->>S: Encrypted Auth Request {type: "auth_req", ct: AES-128-CBC(action, user, pwd, salt)}
    S->>DB: Parameterized Query (users table: salt, SHA-256(salt || pwd))
    DB-->>S: Return stored hash
    Note over S: Constant-time verification using hmac.compare_digest
    S->>C: Encrypted Auth Response {type: "auth_resp", ct: AES-128-CBC(status: "OK")}

    Note over C,S: Step 4 & 5: Fresh Authenticated DH Exchange (Session Key Agreement)
    S->>C: Session DH {type: "session_dh", dh_pub: Y_s2, nonce: N_s, sig: RSA_Sign(sk_s, Y_s2 || N_s)}
    Note over C: Client verifies server RSA signature with Server Cert public key (MITM Prevention)
    C->>S: Session DH {type: "session_dh", dh_pub: Y_c2, nonce: N_c, sig: RSA_Sign(sk_c, Y_c2 || N_c)}
    Note over S: Server verifies client RSA signature with Client Cert public key
    Note over C,S: Derive K_session = Trunc16(SHA-256(big_endian(shared_secret)))
    S->>C: Session Ready {type: "session_ready", status: "OK"}

    Note over C,S: Step 6 & 7: Secure Data Plane (Encrypted & Signed Chat)
    loop Active Chat Session
        Note over C: 1. ct = AES-128-CBC(msg, IV)<br/>2. h = SHA-256(seqno || ts || ct)<br/>3. sig = RSA_Sign(sk_c, h)
        C->>S: Message {type: "msg", seqno: n, ts: ms, ct: base64, sig: base64}
        Note over S: 4-Step Verification:<br/>1. seqno > last_seqno (REPLAY check)<br/>2. |ts - now| <= 60s (STALE check)<br/>3. RSA_Verify(pk_c, h, sig) (SIG_FAIL check)<br/>4. AES-128-CBC Decrypt (DECRYPT_FAIL check)
        Note over S: Append to transcripts/<session>_server.log
        S-->>C: Relay to other room participants (encrypted under their session keys)
    end

    Note over C,S: Step 8: Evidence Plane (Non-Repudiation SessionReceipt Exchange)
    C->>S: Quit Request {type: "quit", peer_summary: {first_seq, last_seq, transcript_sha256}}
    S->>C: Receipt Exchange {receipt_for_peer: Server_Signed_Receipt, server_summary: {...}}
    C->>S: Receipt Ack {receipt_pkg: Client_Signed_Receipt}
    Note over C,S: Both save signed SessionReceipts for offline verification
```

---

## 2. Security Threat Model & Defense Checklist

| Threat | Security Vulnerability | Cryptographic Defense Mechanism | Implementation File(s) |
| :--- | :--- | :--- | :--- |
| **Eavesdropping** | Plaintext packet sniffing | **AES-128-CBC** encryption with random 16-byte IV prepended per message & PKCS#7 padding | [aes.py](file:///d:/CNS_courseproject/app/crypto/aes.py) |
| **Tampering** | In-transit bit-flipping / modification | **SHA-256** message hashing combined with **RSA Digital Signatures** (PKCS#1 v1.5) | [sign.py](file:///d:/CNS_courseproject/app/crypto/sign.py), [session.py](file:///d:/CNS_courseproject/app/crypto/session.py) |
| **Impersonation** | Man-in-the-Middle (MITM) & spoofing | **Mutual X.509 Certificate Validation** signed by Root CA + **Signed DH exchanges** | [pki.py](file:///d:/CNS_courseproject/app/crypto/pki.py), [dh.py](file:///d:/CNS_courseproject/app/crypto/dh.py) |
| **Replay Attacks** | Capturing and resending valid packets | **Monotonically increasing Sequence Numbers** (`seqno > last_seqno`) | [session.py](file:///d:/CNS_courseproject/app/crypto/session.py) |
| **Stale Messages** | Delayed packet injection | **Timestamp freshness validation** within a $\pm 60$-second window | [session.py](file:///d:/CNS_courseproject/app/crypto/session.py) |
| **Denial of Origin** | Repudiating sent messages | **Append-only cryptographic transcripts** + RSA-signed **SessionReceipts** | [transcript.py](file:///d:/CNS_courseproject/app/storage/transcript.py), [verify_transcript.py](file:///d:/CNS_courseproject/tools/verify_transcript.py) |
| **Credential Theft** | Wire sniffing / Rainbow table attacks | **Ephemeral DH encryption** on wire + **16-byte random salt** + constant-time compare | [db.py](file:///d:/CNS_courseproject/app/storage/db.py), [client.py](file:///d:/CNS_courseproject/app/client.py) |

---

## 3. Project Directory Structure

```
securechat/
├── README.md                 # Project documentation and guide
├── requirements.txt          # Python dependencies
├── .env.example              # Environment variables template
├── .gitignore                # Ignores certs/*.key, .env, transcripts/
├── scripts/
│   ├── gen_ca.py             # Generates Root CA (2048-bit RSA + self-signed cert)
│   ├── gen_cert.py           # Issues server/client certs signed by Root CA
│   ├── init_db.py            # Initializes MySQL database & users table
│   ├── demo_attacks.py       # Automated 9-scenario attack demonstration script
│   └── demo_chat_e2e.py      # Automated live multi-client end-to-end chat demo
├── app/
│   ├── client.py             # Multithreaded CLI client with interactive menu
│   ├── server.py             # Multithreaded TCP server with isolated client sessions
│   ├── common/
│   │   ├── protocol.py       # 4-byte big-endian length-prefixed JSON framing
│   │   └── utils.py          # Base64, now_ms(), constant-time comparison
│   ├── crypto/
│   │   ├── pki.py            # X.509 cert validation, CN/dates check, error classes
│   │   ├── dh.py             # RFC 3526 MODP Group 14 DH & Trunc16 AES derivation
│   │   ├── aes.py            # AES-128-CBC encryption/decryption + PKCS#7 padding
│   │   ├── sign.py           # SHA-256 message hashing + RSA sign/verify
│   │   └── session.py        # 4-step receiver verification engine & transcript logger
│   └── storage/
│       ├── db.py             # Parameterized MySQL storage + salted SHA-256 + SQLite fallback
│       └── transcript.py     # Append-only transcript logger & SessionReceipt generation
├── certs/                    # Generated certificates (git-ignored)
├── transcripts/              # Append-only cryptographic logs (git-ignored)
├── tests/
│   ├── test_pki.py           # Unit tests for Root CA and certificate verification
│   ├── test_crypto.py        # Unit tests for DH, AES-128-CBC, RSA signing
│   ├── test_replay_tamper.py # Unit tests for Replay, Stale, and Tampering rejection
│   └── test_transcript.py    # Unit tests for transcripts and offline audit
└── tools/
    └── verify_transcript.py  # Standalone CLI non-repudiation transcript verifier
```

---

## 4. Installation & Setup

### 4.1 Prerequisites
- Python 3.10+
- (Optional) MySQL Server 8.0+ running on port 3306. *(Note: If MySQL is not running, SecureChat automatically and gracefully falls back to a local SQLite database `securechat.db`, so no setup barrier exists.)*

### 4.2 Install Dependencies
```bash
pip install -r requirements.txt
```

### 4.3 Configure Environment (.env)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Default `.env` settings:
```ini
SERVER_HOST=127.0.0.1
SERVER_PORT=8443
DB_TYPE=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=securechat
SQLITE_DB_PATH=securechat.db
CA_CERT_PATH=certs/ca.crt
CA_KEY_PATH=certs/ca.key
SERVER_CERT_PATH=certs/server.crt
SERVER_KEY_PATH=certs/server.key
```

### 4.4 Initialize Database
```bash
python scripts/init_db.py
```

### 4.5 Generate Root CA and Certificates
```bash
# 1. Generate Root Certificate Authority (ca.crt and ca.key)
python scripts/gen_ca.py

# 2. Issue Server Certificate (server.crt and server.key)
python scripts/gen_cert.py server server

# 3. Issue Client Certificates for Alice and Bob
python scripts/gen_cert.py alice client
python scripts/gen_cert.py bob client
```

---

## 5. Running the Application

### 5.1 Start the Server
Open a terminal and run:
```bash
python app/server.py --host 127.0.0.1 --port 8443
```

### 5.2 Start Client 1 (Alice)
Open a second terminal and run:
```bash
python app/client.py --user alice --host 127.0.0.1 --port 8443
```
- Select Option `2` to register (Email: `alice@securechat.io`, Password: `Password123!`).
- Select Option `1` to login (`Password123!`).
- Once authenticated, the secure chat room opens!

### 5.3 Start Client 2 (Bob)
Open a third terminal and run:
```bash
python app/client.py --user bob --host 127.0.0.1 --port 8443
```
- Select Option `2` to register (Email: `bob@securechat.io`, Password: `Password456!`).
- Select Option `1` to login (`Password456!`).
- Once authenticated, Bob and Alice can exchange end-to-end encrypted messages in real-time!

### 5.4 Graceful Session Exit
In either client terminal, type:
```text
/quit
```
Both sides will finalize their append-only transcripts, exchange RSA-signed `SessionReceipt`s, and safely terminate.

---

### 5. Start the Web Dashboard UI (Optional)
In addition to the CLI clients, a real-time **Web Interface** is available with an interactive **Cryptographic Packet Inspector**, attack simulator, and evidence audit panel:
```bash
python app/web_ui.py
```
Open **`http://127.0.0.1:5000`** in your web browser. From the dashboard you can:
- Select Alice or Bob identity and run mutual PKI handshake.
- Perform encrypted registration/login with temporary Diffie-Hellman channel.
- Complete fresh authenticated DH exchange and derive AES-128 session key.
- Send encrypted chat messages and inspect raw packets (`seqno`, `ts`, `ct`, `sig`).
- Launch live simulated attacks (tamper ciphertext, replay, stale timestamps) and view defensive rejections.
- Audit transcripts and verify SessionReceipts with 1 click.

---

## 6. Offline Non-Repudiation Verification

SecureChat enables third-party or offline mathematical verification of any recorded session.

Run `tools/verify_transcript.py` with the transcript log, signed receipt, and peer certificate:
```bash
# Verify Alice's messages at the server:
python tools/verify_transcript.py transcripts/<session_id>_server.log transcripts/<session_id>_server_peer_receipt.json certs/alice.crt
```
**Sample Output:**
```text
=================================================================
      SecureChat Cryptographic Transcript Verifier      
=================================================================
[+] Loaded Peer Certificate. Fingerprint: 4e568cc1a9066bce...
[PASS] Transcript Hash Match: eededf0db1ece4c904c213d25a09cece7ca9fd4100dc96dc0f4eed52887bb832
[PASS] SessionReceipt RSA Signature: VALID (Non-Repudiation established)
[*] Auditing 1 individual message signature(s)...
[PASS] All 1 Message Signatures: VERIFIED
-----------------------------------------------------------------
[SUCCESS] All non-repudiation cryptographic checks PASSED!
=================================================================
```

---

## 7. Running Tests & Automated Attack Demonstrations

### 7.1 Pytest Test Suite
Run the 18 comprehensive unit tests:
```bash
python -m pytest tests/ -v
```

### 7.2 Automated 9-Scenario Attack Demonstration
Run the attack simulator script:
```bash
python scripts/demo_attacks.py
```
This script actively launches and demonstrates defense against:
1. Untrusted / Self-signed certificate $\rightarrow$ `UNTRUSTED_ISSUER`
2. Expired certificate $\rightarrow$ `CERT_EXPIRED`
3. Certificate Common Name mismatch $\rightarrow$ `CERT_CN_MISMATCH`
4. Tampered ciphertext bit-flip $\rightarrow$ `SIG_FAIL`
5. Replayed message transmission $\rightarrow$ `REPLAY`
6. Stale timestamp message $\rightarrow$ `STALE`
7. Wrong password & duplicate registration $\rightarrow$ `BAD_CREDENTIALS` & `DUPLICATE_USER`
8. Modified transcript line audit $\rightarrow$ Offline verifier catches tampering
9. Cryptographic primitives round-trip (DH + AES-128-CBC + RSA-SHA256)

### 7.3 Automated End-to-End Multi-Client Demo
Run the automated end-to-end script:
```bash
python scripts/demo_chat_e2e.py
```

---

## 8. Wireshark Network Traffic Inspection

To prove that no plaintext data, credentials, or keys travel across the network:
1. Open **Wireshark** and select your Loopback adapter (`Adapter for loopback traffic capture` or `lo0`).
2. Set capture filter: `tcp.port == 8443`.
3. Start the capture and run `python scripts/demo_chat_e2e.py` or chat between Alice and Bob.
4. Inspect the TCP payload bytes:
   - **No Plaintext Passwords**: Passwords travel inside an encrypted JSON ciphertext envelope:
     ```json
     {"type": "auth_req", "ct": "U2FsdGVkX1..."}
     ```
   - **No Plaintext Chat Messages**: Messages are framed as:
     ```json
     {"type": "msg", "seqno": 1, "ts": 1794809211987, "ct": "XjSODRks88nhlv...", "sig": "ZFyQKK40Zi..."}
     ```
   - Plaintext searches for words like `password`, `secret`, or message strings in packet bytes return **zero hits**.

---

## 9. Course Objectives to File Implementation Mapping

| Course Project Objective (from Slides) | Implementing Module / Script | Description |
| :--- | :--- | :--- |
| **Phase 1: PKI & Root CA** | `scripts/gen_ca.py`<br/>`scripts/gen_cert.py`<br/>`app/crypto/pki.py` | 2048-bit RSA Root CA key + self-signed X.509 certificate; identity cert issuing (CN, SAN, serverAuth/clientAuth); certificate signature, expiry, and CN validation with custom exceptions. |
| **Phase 2: Control Plane & Encrypted Auth** | `app/server.py`<br/>`app/client.py`<br/>`app/storage/db.py`<br/>`scripts/init_db.py` | Mutual X.509 cert validation; ephemeral Diffie-Hellman credentials protection channel; MySQL parameterized storage; 16-byte random salt + constant-time hash compare. |
| **Phase 3: Authenticated Key Agreement** | `app/crypto/dh.py` | RFC 3526 2048-bit MODP Group 14 DH exchange; $1 < y < p - 1$ validation; RSA digital signature of DH public keys + nonces; session key derivation $K = \text{Trunc}_{16}(\text{SHA-256}(\text{shared\_secret}))$. |
| **Phase 4: Encrypted & Signed Data Plane** | `app/crypto/aes.py`<br/>`app/crypto/sign.py`<br/>`app/crypto/session.py` | AES-128-CBC encryption with 16-byte random IV prepended & PKCS#7 padding; $h = \text{SHA-256}(\text{seqno} \parallel \text{ts} \parallel ct)$; RSA PKCS#1 v1.5 signing; strict 4-step receiver verification (`REPLAY`, `STALE`, `SIG_FAIL`, `DECRYPT_FAIL`). |
| **Phase 5: Evidence Plane & Non-Repudiation** | `app/storage/transcript.py`<br/>`tools/verify_transcript.py` | Append-only transcript logging (`seqno \| ts \| ct \| sig \| fp`); TranscriptHash computation; RSA-signed `SessionReceipt`; standalone offline mathematical verifier. |
| **Concurrency & UX** | `app/server.py`<br/>`app/client.py` | Thread-per-client server concurrency with isolated session states; multithreaded CLI client with concurrent send/receive threads; structured logging without credential leakage. |
| **Comprehensive Attack Verification** | `scripts/demo_attacks.py`<br/>`scripts/demo_chat_e2e.py`<br/>`tests/` | Automated test suite and demonstration proving defenses against all 9 threat vectors and attack models. |
