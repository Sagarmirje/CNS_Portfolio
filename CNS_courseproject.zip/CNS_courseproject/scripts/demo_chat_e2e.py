#!/usr/bin/env python3
"""
End-to-End Multi-Client Demonstration Script.
Spawns the SecureChat Server, connects two clients (Alice and Bob),
registers both, authenticates, completes fresh authenticated DH exchanges,
exchanges encrypted/signed messages, terminates sessions, and verifies receipts.
"""

import os
import sys
import threading
import time

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.client import SecureChatClient
from app.common.protocol import send_message
from app.server import SecureChatServer
from tools.verify_transcript import verify_offline_transcript


def run_e2e_demo():
    print("=" * 70)
    print("      Starting SecureChat End-to-End Live Multi-Client Demo      ")
    print("=" * 70)

    # 1. Start Server in background daemon thread
    server = SecureChatServer(host="127.0.0.1", port=8444)
    server_thread = threading.Thread(target=server.start, daemon=True)
    server_thread.start()
    time.sleep(1.0)  # wait for bind

    # 2. Connect Alice
    print("\n--- [Client 1: Alice] Connecting ---")
    alice = SecureChatClient(username="alice", host="127.0.0.1", port=8444)
    assert alice.connect() is True, "Alice failed to connect"

    # Register Alice
    alice.register("alice@securechat.io", "AlicePassword123!")
    assert alice.login("AlicePassword123!") is True, "Alice login failed"
    assert alice.establish_session_key() is True, "Alice session key agreement failed"

    # Start Alice receive thread
    alice_recv = threading.Thread(target=alice._receive_loop, daemon=True)
    alice_recv.start()

    # 3. Connect Bob
    print("\n--- [Client 2: Bob] Connecting ---")
    bob = SecureChatClient(username="bob", host="127.0.0.1", port=8444)
    assert bob.connect() is True, "Bob failed to connect"

    # Register Bob
    bob.register("bob@securechat.io", "BobPassword456!")
    assert bob.login("BobPassword456!") is True, "Bob login failed"
    assert bob.establish_session_key() is True, "Bob session key agreement failed"

    bob_recv = threading.Thread(target=bob._receive_loop, daemon=True)
    bob_recv.start()

    # 4. Exchange Encrypted & Signed Messages
    print("\n--- [Data Plane] Sending Messages ---")
    # Alice -> Bob
    msg1 = alice.session.create_message("Hi Bob, this message is AES-128 encrypted and signed by Alice!")
    send_message(alice.sock, msg1)
    time.sleep(0.5)

    # Bob -> Alice
    msg2 = bob.session.create_message("Hi Alice, verified your signature. Secure communication active.")
    send_message(bob.sock, msg2)
    time.sleep(0.5)

    # 5. Session Termination & Mutual Receipt Generation
    print("\n--- [Evidence Plane] Session Termination & Non-Repudiation ---")
    # Alice sends quit with summary
    alice_t_hash = alice.session.transcript.compute_transcript_hash()
    send_message(
        alice.sock,
        {
            "type": "quit",
            "peer_summary": {
                "first_seq": alice.session.transcript.first_seq or 0,
                "last_seq": alice.session.transcript.last_seq or 0,
                "transcript_sha256": alice_t_hash,
            },
        },
    )
    time.sleep(0.5)

    # Bob sends quit with summary
    bob_t_hash = bob.session.transcript.compute_transcript_hash()
    send_message(
        bob.sock,
        {
            "type": "quit",
            "peer_summary": {
                "first_seq": bob.session.transcript.first_seq or 0,
                "last_seq": bob.session.transcript.last_seq or 0,
                "transcript_sha256": bob_t_hash,
            },
        },
    )
    time.sleep(0.8)

    alice.is_connected = False
    bob.is_connected = False
    alice.sock.close()
    bob.sock.close()
    server.stop()

    # 6. Audit Alice's and Bob's messages at the Server using their certificates and signed receipts!
    print("\n--- Offline Transcript Verification for Alice and Bob ---")
    verified_count = 0
    for fname in os.listdir("transcripts"):
        if fname.endswith("_server_peer_receipt.json"):
            receipt_path = os.path.join("transcripts", fname)
            sess_id = fname.split("_")[0]
            log_path = os.path.join("transcripts", f"{sess_id}_server.log")
            if os.path.exists(log_path):
                # Check with alice.crt or bob.crt
                for cert_name in ["alice", "bob"]:
                    cert_file = f"certs/{cert_name}.crt"
                    print(f"\n[*] Trying audit for {log_path} against {cert_file}...")
                    if verify_offline_transcript(log_path, receipt_path, cert_file):
                        print(f"[+] Successfully verified {log_path} as authored by {cert_name.upper()}!")
                        verified_count += 1
                        break

    assert verified_count >= 2, f"Expected at least 2 verified transcripts, got {verified_count}"

    print("\n" + "=" * 70)
    print("      SUCCESS: Live End-to-End Multi-Client Demo Completed!      ")
    print("=" * 70)


if __name__ == "__main__":
    run_e2e_demo()
