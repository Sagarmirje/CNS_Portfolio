#!/usr/bin/env python3
"""
Certificate Generation Script.
Issues an RSA 2048-bit private key and an X.509 certificate signed by the Root CA.
Usage: python scripts/gen_cert.py <name> <server|client>
"""

import argparse
import datetime
import ipaddress
import os
import sys

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.common.utils import set_private_key_permissions


def issue_certificate(
    name: str,
    role: str,
    output_dir: str = "certs",
    ca_key_path: str = "certs/ca.key",
    ca_cert_path: str = "certs/ca.crt",
    validity_days: int = 365,
    custom_cn: str | None = None,
) -> tuple[str, str]:
    """
    Issue an identity certificate signed by Root CA.
    role must be either 'server' or 'client'.
    """
    role = role.lower()
    if role not in ("server", "client"):
        raise ValueError("Role must be 'server' or 'client'.")

    if not os.path.exists(ca_key_path) or not os.path.exists(ca_cert_path):
        raise FileNotFoundError(
            f"Root CA files missing. Please run gen_ca.py first. (Checked: {ca_key_path}, {ca_cert_path})"
        )

    # Load CA private key and certificate
    with open(ca_key_path, "rb") as f:
        ca_private_key = serialization.load_pem_private_key(f.read(), password=None)
    with open(ca_cert_path, "rb") as f:
        ca_cert = x509.load_pem_x509_certificate(f.read())

    # Generate identity RSA key
    print(f"[*] Generating 2048-bit RSA key for {name} ({role})...")
    entity_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    common_name = custom_cn if custom_cn else name
    subject = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SecureChat Network"),
        x509.NameAttribute(NameOID.COMMON_NAME, common_name),
    ])

    now = datetime.datetime.now(datetime.timezone.utc)
    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(ca_cert.subject)
        .public_key(entity_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(minutes=5))
        .not_valid_after(now + datetime.timedelta(days=validity_days))
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None),
            critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_encipherment=True,
                key_cert_sign=False,
                crl_sign=False,
                content_commitment=False,
                data_encipherment=False,
                key_agreement=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(entity_key.public_key()),
            critical=False,
        )
        .add_extension(
            x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_cert.public_key()),
            critical=False,
        )
    )

    # Configure role-specific extensions
    if role == "server":
        builder = builder.add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),
            critical=False,
        )
        # Add Subject Alternative Names (SAN) for server
        san_list = [
            x509.DNSName("localhost"),
            x509.DNSName(name),
            x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        ]
        builder = builder.add_extension(
            x509.SubjectAlternativeName(san_list),
            critical=False,
        )
    else:
        builder = builder.add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]),
            critical=False,
        )

    # Sign with CA private key
    cert = builder.sign(ca_private_key, hashes.SHA256())

    os.makedirs(output_dir, exist_ok=True)
    key_path = os.path.join(output_dir, f"{name}.key")
    cert_path = os.path.join(output_dir, f"{name}.crt")

    with open(key_path, "wb") as f:
        f.write(
            entity_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )
    set_private_key_permissions(key_path)

    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    print(f"[+] Key saved to: {key_path}")
    print(f"[+] Cert saved to: {cert_path}")
    return key_path, cert_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Issue certificate signed by Root CA.")
    parser.add_argument("name", help="Identity name (e.g. server, alice, bob)")
    parser.add_argument("role", choices=["server", "client"], help="Role type (server or client)")
    parser.add_argument("--dir", default="certs", help="Output directory (default: certs)")
    parser.add_argument("--days", type=int, default=365, help="Validity period in days (default: 365)")
    args = parser.parse_args()

    issue_certificate(
        name=args.name,
        role=args.role,
        output_dir=args.dir,
        validity_days=args.days,
    )


if __name__ == "__main__":
    main()
