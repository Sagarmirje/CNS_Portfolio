#!/usr/bin/env python3
"""
SecureChat Automated Attack Demonstration Script.
Demonstrates that the hybrid cryptographic architecture successfully defeats
all 9 security threats and attack vectors required by the project specification.

Demonstration Scenarios:
 1. Untrusted / Self-Signed Certificate -> UNTRUSTED_ISSUER
 2. Expired Certificate -> CERT_EXPIRED
 3. Certificate Common Name Mismatch -> CERT_CN_MISMATCH
 4. Tampered Ciphertext (bit-flip in transit) -> SIG_FAIL
 5. Replayed Message (sequence number reuse) -> REPLAY
 6. Stale Message (timestamp outside window) -> STALE
 7. Credential Attacks (wrong password & duplicate user) -> BAD_CREDENTIALS / DUPLICATE_USER
 8. Tampered Transcript File -> FAIL in Offline Verifier
 9. End-to-End Cryptographic Roundtrip (DH + AES-128-CBC + RSA-SHA256)
"""

import datetime
import hashlib
import os
import shutil
import sys
import tempfile

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.common.utils import b64_decode, b64_encode, now_ms
from app.crypto.aes import decrypt_aes_cbc, encrypt_aes_cbc
from app.crypto.dh import DiffieHellman
from app.crypto.pki import (
    BAD_CERT_SIGNATURE,
    CERT_CN_MISMATCH,
    CERT_EXPIRED,
    UNTRUSTED_ISSUER,
    certificate_to_pem,
    validate_certificate,
)
from app.crypto.session import SecureChatSession
from app.crypto.sign import compute_message_hash, sign_hash, verify_hash
from app.storage.db import DatabaseManager
from app.storage.transcript import TranscriptLogger
from tools.verify_transcript import verify_offline_transcript


def print_banner(title: str) -> None:
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def create_mock_ca():
    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "SecureChat Root CA")])
    now = datetime.datetime.now(datetime.timezone.utc)
    ca_cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(ca_key.public_key())
        .serial_number(1)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(ca_key, hashes.SHA256())
    )
    return ca_key, ca_cert


def main():
    print_banner("SecureChat: Comprehensive Hybrid Cryptography Defense Demo")
    results = {}

    ca_key, ca_cert = create_mock_ca()
    ca_pem = certificate_to_pem(ca_cert)

    # -------------------------------------------------------------
    # Scenario 1: Untrusted / Self-signed certificate
    # -------------------------------------------------------------
    print("\n[Scenario 1] Attacker connects with self-signed rogue certificate...")
    rogue_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    rogue_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "attacker")]))
        .issuer_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "attacker")]))
        .public_key(rogue_key.public_key())
        .serial_number(666)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(rogue_key, hashes.SHA256())
    )
    rogue_pem = certificate_to_pem(rogue_cert)

    try:
        validate_certificate(rogue_pem, ca_pem)
        print("[-] FAIL: Rogue certificate was accepted!")
        results["1. Untrusted Cert"] = "FAIL"
    except UNTRUSTED_ISSUER as e:
        print(f"[+] DEFENSE ACTIVE: Rejected with UNTRUSTED_ISSUER ({e})")
        results["1. Untrusted Cert"] = "PASS (UNTRUSTED_ISSUER)"

    # -------------------------------------------------------------
    # Scenario 2: Expired certificate
    # -------------------------------------------------------------
    print("\n[Scenario 2] Client presents an expired certificate...")
    expired_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(rogue_key.public_key())
        .serial_number(667)
        .not_valid_before(now - datetime.timedelta(days=40))
        .not_valid_after(now - datetime.timedelta(days=10))
        .sign(ca_key, hashes.SHA256())
    )
    expired_pem = certificate_to_pem(expired_cert)

    try:
        validate_certificate(expired_pem, ca_pem, expected_cn="alice")
        print("[-] FAIL: Expired cert was accepted!")
        results["2. Expired Cert"] = "FAIL"
    except CERT_EXPIRED as e:
        print(f"[+] DEFENSE ACTIVE: Rejected with CERT_EXPIRED ({e})")
        results["2. Expired Cert"] = "PASS (CERT_EXPIRED)"

    # -------------------------------------------------------------
    # Scenario 3: Wrong CN certificate
    # -------------------------------------------------------------
    print("\n[Scenario 3] Client certificate CN does not match claimed identity...")
    legit_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "charlie")]))
        .issuer_name(ca_cert.subject)
        .public_key(rogue_key.public_key())
        .serial_number(668)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(ca_key, hashes.SHA256())
    )
    legit_pem = certificate_to_pem(legit_cert)

    try:
        validate_certificate(legit_pem, ca_pem, expected_cn="alice")
        print("[-] FAIL: Wrong CN was accepted!")
        results["3. Wrong CN"] = "FAIL"
    except CERT_CN_MISMATCH as e:
        print(f"[+] DEFENSE ACTIVE: Rejected with CERT_CN_MISMATCH ({e})")
        results["3. Wrong CN"] = "PASS (CERT_CN_MISMATCH)"

    # -------------------------------------------------------------
    # Set up sessions for message checks
    # -------------------------------------------------------------
    temp_dir = tempfile.mkdtemp()
    alice_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    bob_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    alice_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "alice")]))
        .issuer_name(ca_cert.subject)
        .public_key(alice_key.public_key())
        .serial_number(1001)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(ca_key, hashes.SHA256())
    )
    bob_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "bob")]))
        .issuer_name(ca_cert.subject)
        .public_key(bob_key.public_key())
        .serial_number(1002)
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=30))
        .sign(ca_key, hashes.SHA256())
    )

    shared_k = os.urandom(16)
    alice_sess = SecureChatSession("demo_sess", "client", shared_k, alice_key, bob_cert, transcripts_dir=temp_dir)
    bob_sess = SecureChatSession("demo_sess", "server", shared_k, bob_key, alice_cert, transcripts_dir=temp_dir)

    # -------------------------------------------------------------
    # Scenario 4: Tampered Ciphertext
    # -------------------------------------------------------------
    print("\n[Scenario 4] Attacker modifies 1 byte in the ciphertext in transit...")
    msg = alice_sess.create_message("Transfer $1000 to Bob")
    # Tamper with ct
    raw_ct = bytearray(b64_decode(msg["ct"]))
    raw_ct[-1] ^= 0x01
    tampered_msg = dict(msg)
    tampered_msg["ct"] = b64_encode(bytes(raw_ct))

    ok, code, reason = bob_sess.process_incoming_message(tampered_msg)
    if not ok and code == "SIG_FAIL":
        print(f"[+] DEFENSE ACTIVE: Tampering detected before decryption! Status: {code} ({reason})")
        results["4. Tampered Ciphertext"] = "PASS (SIG_FAIL)"
    else:
        print(f"[-] FAIL: Tampered message was not caught by signature: {code}")
        results["4. Tampered Ciphertext"] = "FAIL"

    # -------------------------------------------------------------
    # Scenario 5: Replayed Message
    # -------------------------------------------------------------
    print("\n[Scenario 5] Attacker captures and replays a valid message...")
    valid_msg = alice_sess.create_message("Approve Invoice #402")
    # First delivery
    bob_sess.process_incoming_message(valid_msg)

    # Attacker retransmits valid_msg
    replay_ok, replay_code, replay_reason = bob_sess.process_incoming_message(valid_msg)
    if not replay_ok and replay_code == "REPLAY":
        print(f"[+] DEFENSE ACTIVE: Replay rejected! Status: {replay_code} ({replay_reason})")
        results["5. Replay Attack"] = "PASS (REPLAY)"
    else:
        print(f"[-] FAIL: Replay message was accepted!")
        results["5. Replay Attack"] = "FAIL"

    # -------------------------------------------------------------
    # Scenario 6: Stale Timestamp
    # -------------------------------------------------------------
    print("\n[Scenario 6] Attacker transmits message with stale timestamp (+5 minutes old)...")
    stale_msg = alice_sess.create_message("Time sensitive instruction")
    stale_msg["ts"] = stale_msg["ts"] - 300000  # 5 minutes old
    # Re-sign so only timestamp is wrong
    h = compute_message_hash(stale_msg["seqno"], stale_msg["ts"], stale_msg["ct"])
    stale_msg["sig"] = b64_encode(sign_hash(alice_key, h))

    stale_ok, stale_code, stale_reason = bob_sess.process_incoming_message(stale_msg)
    if not stale_ok and stale_code == "STALE":
        print(f"[+] DEFENSE ACTIVE: Stale timestamp rejected! Status: {stale_code} ({stale_reason})")
        results["6. Stale Timestamp"] = "PASS (STALE)"
    else:
        print(f"[-] FAIL: Stale message accepted: {stale_code}")
        results["6. Stale Timestamp"] = "FAIL"

    # -------------------------------------------------------------
    # Scenario 7: Credential Attacks (Wrong Password & Duplicate Registration)
    # -------------------------------------------------------------
    print("\n[Scenario 7] Testing password verification & duplicate registration...")
    db_test_path = os.path.join(temp_dir, "test_auth.db")
    db = DatabaseManager(db_type="sqlite", sqlite_path=db_test_path)

    # Register legitimate user
    reg_ok, _ = db.register_user("alice@securechat.io", "alice", "SecretPassword123!")
    dup_ok, dup_status = db.register_user("alice@securechat.io", "alice", "AnotherPassword!")
    login_wrong_ok, login_wrong_status = db.verify_user("alice", "WrongPassword!")
    login_right_ok, login_right_status = db.verify_user("alice", "SecretPassword123!")

    if reg_ok and (not dup_ok and dup_status == "DUPLICATE_USER") and (not login_wrong_ok and login_wrong_status == "BAD_CREDENTIALS") and login_right_ok:
        print("[+] DEFENSE ACTIVE: Duplicate user blocked (DUPLICATE_USER) & wrong password rejected (BAD_CREDENTIALS)!")
        results["7. Credential Attacks"] = "PASS (BAD_CREDENTIALS & DUPLICATE_USER)"
    else:
        print("[-] FAIL: Database credential behavior error.")
        results["7. Credential Attacks"] = "FAIL"

    # -------------------------------------------------------------
    # Scenario 8: Modified Transcript Line (Non-Repudiation Audit)
    # -------------------------------------------------------------
    print("\n[Scenario 8] Auditing tampered transcript with tools/verify_transcript.py...")
    transcript_logger = TranscriptLogger("audit_sess", "client", bob_cert, transcripts_dir=temp_dir)
    ts = now_ms()
    ct = b64_encode(encrypt_aes_cbc(shared_k, b"Legal contract agreement"))
    h = compute_message_hash(1, ts, ct)
    sig = b64_encode(sign_hash(alice_key, h))
    transcript_logger.log_message(1, ts, ct, sig)

    receipt = transcript_logger.generate_receipt(alice_key, peer_name="bob")
    receipt_path = transcript_logger.save_receipt(receipt)

    alice_cert_path = os.path.join(temp_dir, "alice.crt")
    with open(alice_cert_path, "wb") as f:
        f.write(alice_cert.public_bytes(serialization.Encoding.PEM))

    # Tamper with transcript
    with open(transcript_logger.file_path, "r", encoding="utf-8") as f:
        t_data = f.read()
    tampered_t_data = t_data.replace(ct[:6], "ZZZZZZ")
    with open(transcript_logger.file_path, "w", encoding="utf-8") as f:
        f.write(tampered_t_data)

    audit_result = verify_offline_transcript(transcript_logger.file_path, receipt_path, alice_cert_path)
    if not audit_result:
        print("[+] DEFENSE ACTIVE: Offline verifier caught tampered transcript line!")
        results["8. Transcript Tampering"] = "PASS (Detected by Verifier)"
    else:
        print("[-] FAIL: Tampered transcript was not detected!")
        results["8. Transcript Tampering"] = "FAIL"

    # -------------------------------------------------------------
    # Scenario 9: Cryptographic Round-Trip
    # -------------------------------------------------------------
    print("\n[Scenario 9] Cryptographic primitives round-trip (DH + AES + RSA)...")
    dh1 = DiffieHellman()
    dh2 = DiffieHellman()
    k1 = dh1.derive_key(dh2.public_key)
    k2 = dh2.derive_key(dh1.public_key)

    plaintext = b"Hybrid Cryptography End-to-End Verification"
    ciphertext = encrypt_aes_cbc(k1, plaintext)
    decrypted = decrypt_aes_cbc(k2, ciphertext)

    sig_rt = sign_hash(alice_key, compute_message_hash(10, 1000, "sample"))
    ver_rt = verify_hash(alice_key.public_key(), compute_message_hash(10, 1000, "sample"), sig_rt)

    if k1 == k2 and decrypted == plaintext and ver_rt is True:
        print("[+] CRYPTO ACTIVE: DH matched, AES-128-CBC decrypted cleanly, RSA verified!")
        results["9. Crypto Roundtrip"] = "PASS"
    else:
        print("[-] FAIL: Cryptographic roundtrip failure.")
        results["9. Crypto Roundtrip"] = "FAIL"

    # Cleanup temp
    shutil.rmtree(temp_dir, ignore_errors=True)

    # -------------------------------------------------------------
    # Final Summary Table
    # -------------------------------------------------------------
    print_banner("Attack & Security Defense Summary Table")
    all_pass = True
    for scenario, status in results.items():
        print(f"  {scenario:<30} : {status}")
        if not status.startswith("PASS"):
            all_pass = False

    print("=" * 70)
    if all_pass:
        print("  ALL 9 SECURITY CONTROLS AND DEFENSES VERIFIED SUCCESSFULLY!")
    else:
        print("  SOME CONTROLS FAILED VERIFICATION.")
    print("=" * 70)


if __name__ == "__main__":
    main()
