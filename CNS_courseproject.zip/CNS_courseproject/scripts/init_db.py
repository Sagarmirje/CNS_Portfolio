#!/usr/bin/env python3
"""
Database Initialization Script.
Connects to the database and initializes the users table with secure schema.
"""

import os
import sys

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.storage.db import DatabaseManager


def main() -> None:
    print("[*] Initializing SecureChat database...")
    db = DatabaseManager()
    print(f"[+] Database storage ready! Backend in use: {db.db_type.upper()}")
    if db.db_type == "mysql":
        print(f"[+] MySQL Database: {db.database} on {db.host}:{db.port}")
    else:
        print(f"[+] SQLite file: {db.sqlite_path}")


if __name__ == "__main__":
    main()
