from PIL import Image, ImageDraw, ImageFont

W, H = 2200, 1450
img = Image.new("RGB", (W, H), "#F8FBFF")
d = ImageDraw.Draw(img)

NAVY = "#17324D"
BLUE = "#2563EB"
CYAN = "#0891B2"
GREEN = "#16A34A"
PURPLE = "#7C3AED"
ORANGE = "#EA580C"
RED = "#DC2626"
LIGHT_BLUE = "#EAF2FF"
LIGHT_CYAN = "#E7F8FA"
LIGHT_GREEN = "#ECFDF3"
LIGHT_PURPLE = "#F5F3FF"
LIGHT_ORANGE = "#FFF7ED"
WHITE = "#FFFFFF"
GRAY = "#64748B"
LINE = "#94A3B8"

try:
    title_font = ImageFont.truetype("arial.ttf", 46)
    subtitle_font = ImageFont.truetype("arial.ttf", 21)
    step_font = ImageFont.truetype("arial.ttf", 27)
    head_font = ImageFont.truetype("arial.ttf", 22)
    body_font = ImageFont.truetype("arial.ttf", 18)
    small_font = ImageFont.truetype("arial.ttf", 16)
except Exception:
    title_font = subtitle_font = step_font = head_font = body_font = small_font = None


def arrow(x1, y1, x2, y2, color=BLUE, width=5, label=None):
    d.line((x1, y1, x2, y2), fill=color, width=width)
    import math
    ang = math.atan2(y2-y1, x2-x1)
    size = 15
    pts = [(x2, y2),
           (x2-size*math.cos(ang-0.45), y2-size*math.sin(ang-0.45)),
           (x2-size*math.cos(ang+0.45), y2-size*math.sin(ang+0.45))]
    d.polygon(pts, fill=color)
    if label:
        px = (x1+x2)//2 - 70
        py = (y1+y2)//2 - 32
        box = d.textbbox((px, py), label, font=small_font)
        d.rounded_rectangle((box[0]-8, box[1]-6, box[2]+8, box[3]+6), radius=8, fill=WHITE, outline=LINE)
        d.text((px, py), label, fill=NAVY, font=small_font)


def node(x, y, w, h, number, title, details, accent, fill):
    d.rounded_rectangle((x, y, x+w, y+h), radius=20, fill=fill, outline=accent, width=3)
    d.ellipse((x+18, y+18, x+72, y+72), fill=accent)
    d.text((x+34, y+25), number, fill=WHITE, font=step_font, anchor="mm")
    d.text((x+88, y+20), title, fill=NAVY, font=head_font)
    d.text((x+22, y+82), details, fill=NAVY, font=body_font, spacing=7)

# Header
d.text((90, 50), "SecureChat — 8-Step Protocol Flow", fill=NAVY, font=title_font)
d.text((94, 110), "From TCP connection to encrypted chat and signed SessionReceipt exchange", fill=GRAY, font=subtitle_font)

# Client and server swim lanes
d.rounded_rectangle((70, 180, 2125, 1250), radius=25, fill=WHITE, outline="#D8E2F0", width=3)
d.rounded_rectangle((70, 180, 350, 1250), radius=25, fill=LIGHT_BLUE, outline="#B9CDF3", width=2)
d.text((105, 210), "SYSTEM", fill=BLUE, font=head_font)
d.text((105, 260), "ACTORS", fill=GRAY, font=small_font)

# Left actor labels
d.text((105, 380), "ALICE", fill=BLUE, font=head_font)
d.text((105, 420), "BOB", fill=BLUE, font=head_font)
d.text((105, 670), "SERVER", fill=CYAN, font=head_font)
d.text((105, 940), "RECEIVER", fill=GREEN, font=head_font)
d.text((105, 1120), "AUDIT", fill=ORANGE, font=head_font)

# Flow nodes — top lane
node(390, 220, 360, 155, "1", "TCP Connection", "• Client connects to port 8443\n• Multithreaded server accepts connection", BLUE, LIGHT_BLUE)
node(820, 220, 390, 155, "2", "Mutual PKI Authentication", "• Exchange X.509 certificates\n• Validate issuer, CN and validity", BLUE, LIGHT_BLUE)
node(1280, 220, 390, 155, "3", "Ephemeral DH + Login", "• Derive temporary AES-128 key\n• Encrypt registration/login payload", PURPLE, LIGHT_PURPLE)

# Mid lane
node(390, 470, 390, 155, "4", "Authenticated Session DH", "• Generate fresh DH public values\n• Sign public value and nonce with RSA", CYAN, LIGHT_CYAN)
node(850, 470, 390, 155, "5", "Session Key Agreement", "• Verify peer RSA signature\n• Derive fresh AES-128 session key", CYAN, LIGHT_CYAN)
node(1310, 470, 390, 155, "6", "Encrypted & Signed Chat", "• AES-CBC encrypt message\n• SHA-256 hash + RSA signature", GREEN, LIGHT_GREEN)

# Receiver validation lane
node(390, 720, 300, 285, "7", "Receiver Validation", "1. Sequence > last accepted\n2. Timestamp within ±60 sec\n3. Verify RSA signature\n4. AES-CBC decrypt\n\nReject: REPLAY / STALE /\nSIG_FAIL / DECRYPT_FAIL", GREEN, LIGHT_GREEN)

# Rejection outcomes
outcomes = [
    (760, 760, "REPLAY", RED, "#FFF1F2"),
    (760, 835, "STALE", ORANGE, LIGHT_ORANGE),
    (760, 910, "SIG_FAIL", RED, "#FFF1F2"),
]
for x, y, text, accent, fill in outcomes:
    d.rounded_rectangle((x, y, x+230, y+52), radius=14, fill=fill, outline=accent, width=2)
    d.text((x+115, y+26), text, fill=accent, font=small_font, anchor="mm")

# Accepted path
node(1060, 720, 390, 285, "", "Accepted Message", "• Decrypt plaintext\n• Append signed record to transcript\n• Broadcast to verified peers\n• Continue with next sequence number", GREEN, LIGHT_GREEN)

# Step 8 evidence node
node(390, 1060, 1060, 145, "8", "SessionReceipt Exchange", "• Calculate transcript summary • Generate RSA-signed receipt • Exchange receipt acknowledgments • Save evidence for offline audit", ORANGE, LIGHT_ORANGE)

# Main arrows
arrow(750, 298, 820, 298, label="Certificates")
arrow(1210, 298, 1280, 298, label="DH values")
arrow(570, 375, 570, 470, label="Signed DH")
arrow(1040, 547, 1310, 547, label="Session key")
arrow(1505, 625, 690, 720, label="Packet")
arrow(690, 862, 1060, 862, color=GREEN, label="If verified")
arrow(1255, 1005, 920, 1060, color=ORANGE, label="/quit")

# Rejection links
arrow(690, 800, 760, 786, color=RED)
arrow(690, 840, 760, 861, color=ORANGE)
arrow(690, 900, 760, 936, color=RED)

# Legend
d.text((1500, 760), "Legend", fill=NAVY, font=head_font)
legend = [
    (1500, 815, BLUE, "Authentication"),
    (1500, 860, PURPLE, "Key derivation"),
    (1500, 905, GREEN, "Secure data plane"),
    (1500, 950, ORANGE, "Evidence plane"),
]
for x, y, color, text in legend:
    d.rounded_rectangle((x, y, x+28, y+28), radius=8, fill=color)
    d.text((x+42, y+2), text, fill=NAVY, font=small_font)

# Bottom security summary
d.rounded_rectangle((1500, 1060, 2050, 1205), radius=18, fill="#FFFFFF", outline="#D8E2F0", width=2)
d.text((1530, 1085), "Security Properties", fill=NAVY, font=head_font)
d.text((1530, 1130), "Confidentiality  •  Integrity", fill=BLUE, font=small_font)
d.text((1530, 1160), "Authentication  •  Replay / Freshness", fill=CYAN, font=small_font)

img.save(r"d:\CNS_courseproject\SecureChat_Flow_Diagram.png", quality=95)
print(r"d:\CNS_courseproject\SecureChat_Flow_Diagram.png")
