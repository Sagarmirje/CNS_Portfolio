from PIL import Image, ImageDraw, ImageFont

W, H = 1800, 1100
img = Image.new("RGB", (W, H), "#F7FAFC")
d = ImageDraw.Draw(img)

COLORS = {
    "navy": "#17324D", "blue": "#2563EB", "cyan": "#0891B2",
    "green": "#16A34A", "orange": "#EA580C", "purple": "#7C3AED",
    "gray": "#64748B", "lightblue": "#EAF2FF", "lightcyan": "#E7F8FA",
    "lightgreen": "#ECFDF3", "lightorange": "#FFF7ED", "lightpurple": "#F5F3FF",
    "line": "#94A3B8", "white": "#FFFFFF"
}

try:
    title_font = ImageFont.truetype("arial.ttf", 48)
    subtitle_font = ImageFont.truetype("arial.ttf", 22)
    header_font = ImageFont.truetype("arial.ttf", 25)
    body_font = ImageFont.truetype("arial.ttf", 20)
    small_font = ImageFont.truetype("arial.ttf", 17)
except Exception:
    title_font = subtitle_font = header_font = body_font = small_font = None


def rounded_box(x, y, w, h, fill, outline, header, body, accent):
    d.rounded_rectangle((x, y, x+w, y+h), radius=22, fill=fill, outline=outline, width=3)
    d.rounded_rectangle((x, y, x+w, y+58), radius=22, fill=accent)
    d.rectangle((x, y+36, x+w, y+58), fill=accent)
    d.text((x+22, y+12), header, fill=COLORS["white"], font=header_font)
    d.text((x+22, y+78), body, fill=COLORS["navy"], font=body_font, spacing=8)


def arrow(x1, y1, x2, y2, label="", label_pos=None, color=None):
    color = color or COLORS["blue"]
    d.line((x1, y1, x2, y2), fill=color, width=5)
    import math
    ang = math.atan2(y2-y1, x2-x1)
    size = 14
    pts = [(x2,y2),
           (x2-size*math.cos(ang-0.45), y2-size*math.sin(ang-0.45)),
           (x2-size*math.cos(ang+0.45), y2-size*math.sin(ang+0.45))]
    d.polygon(pts, fill=color)
    if label:
        px, py = label_pos or ((x1+x2)/2, (y1+y2)/2-28)
        box = d.textbbox((px, py), label, font=small_font)
        d.rounded_rectangle((box[0]-8, box[1]-5, box[2]+8, box[3]+5), radius=8, fill="#FFFFFF", outline="#CBD5E1")
        d.text((px, py), label, fill=COLORS["navy"], font=small_font)

# Title
d.text((90, 55), "SecureChat — System Architecture", fill=COLORS["navy"], font=title_font)
d.text((94, 112), "Hybrid cryptography, mutual authentication, secure data plane, and audit evidence", fill=COLORS["gray"], font=subtitle_font)

# Client and server boxes
rounded_box(75, 220, 390, 610, COLORS["lightblue"], "#B9CDF3", "Client — Alice / Bob", "• Web dashboard\n• Mutual PKI certificate\n• Ephemeral DH key\n• AES-128-CBC encryption\n• RSA digital signatures\n• Replay / freshness checks", COLORS["blue"])

rounded_box(705, 220, 390, 610, COLORS["lightcyan"], "#A8DBDF", "TCP Server", "• Multithreaded handlers\n• Certificate validation\n• Authentication engine\n• Session DH key agreement\n• Message verification\n• Broadcast and receipts", COLORS["cyan"])

# Database and evidence
rounded_box(1335, 220, 390, 270, COLORS["lightgreen"], "#ABE0BE", "Database", "• MySQL / SQLite fallback\n• Users and salted hashes\n• Parameterized queries", COLORS["green"])

rounded_box(1335, 560, 390, 270, COLORS["lightorange"], "#F8C99A", "Evidence Plane", "• Append-only transcripts\n• Transcript SHA-256 hash\n• RSA-signed receipts\n• Offline verifier", COLORS["orange"])

# Protocol flow inside client/server
rounded_box(465, 265, 240, 150, "#FFFFFF", "#CBD5E1", "1–3", "PKI handshake\nEphemeral DH\nEncrypted login", COLORS["purple"])
rounded_box(465, 465, 240, 150, "#FFFFFF", "#CBD5E1", "4–5", "Authenticated DH\nSession key derivation", COLORS["purple"])
rounded_box(465, 665, 240, 150, "#FFFFFF", "#CBD5E1", "6–8", "Encrypted chat\nReceipt exchange", COLORS["purple"])

# Arrows
arrow(465, 340, 705, 340, "Handshake / auth", (520, 295))
arrow(705, 540, 465, 540, "Signed DH exchange", (510, 495), COLORS["cyan"])
arrow(705, 740, 465, 740, "Messages / quit", (525, 695), COLORS["cyan"])
arrow(1095, 390, 1335, 350, "Credential lookup", (1145, 330))
arrow(1095, 695, 1335, 695, "Store evidence", (1140, 650), COLORS["orange"])

# Key security flow band
security_y = 900
bands = [
    (75, "Confidentiality", "AES-128-CBC", COLORS["blue"], COLORS["lightblue"]),
    (420, "Integrity", "SHA-256 + RSA", COLORS["purple"], COLORS["lightpurple"]),
    (765, "Replay Defense", "Sequence + timestamp", COLORS["cyan"], COLORS["lightcyan"]),
    (1110, "Non-Repudiation", "Signed receipts", COLORS["orange"], COLORS["lightorange"]),
]
for x, head, body, accent, fill in bands:
    d.rounded_rectangle((x, security_y, x+300, security_y+120), radius=18, fill=fill, outline=accent, width=3)
    d.text((x+20, security_y+18), head, fill=accent, font=header_font)
    d.text((x+20, security_y+65), body, fill=COLORS["navy"], font=body_font)

# Notes
rounded_box(1410, security_y-10, 315, 140, "#FFFFFF", "#CBD5E1", "Defense in Depth", "Multiple independent\nchecks protect each step", COLORS["gray"])

img.save(r"d:\CNS_courseproject\SecureChat_Architecture_Diagram.png", quality=95)
print(r"d:\CNS_courseproject\SecureChat_Architecture_Diagram.png")
